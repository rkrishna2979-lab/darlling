# Darling — Personal AI Assistant (Android)

Darling ek asli native Android app hai (Kotlin + Jetpack Compose). Dimaag: **Google Gemini**.
Baat-cheet: **Gemini Live** real-time voice — bolo, Darling sunegi, hasegi, bolegi, fir khud sunne lagegi.
Mic button baar-baar dabane ki zaroorat nahi.

Darling Boss ki flirty, caring personal assistant hai — sirf jawab nahi deti, **feel** karti hai:
khushi me hasi, fikr me naram awaaz, nakhre wala cute gussa, aur Boss udaas ho to bilkul soft,
emotional andaaz. Phir bhi kaam hamesha pehle — bina kisi galti ke, fatafat.

## Darling kya-kya kar sakti hai

- **Calling Mode** — continuous voice: LISTEN → THINK → SPEAK → LISTEN. Bolte hue rokna (barge-in) bhi hai.
- **Text Chat** — Gemini se chat, tools ke saath (sirf jawab nahi, kaam bhi).
- **Emotions + Mood** — Darling ka mood badlo awaaz se: "khush ho jao", "gussa ho jao", "serious ho jao" (`set_mood` tool — happy, flirty, caring, angry_pout, sad, serious). Mood agle replies par apne aap lagu hota hai.
- **Personality modes (Settings)** — **Flirty** (default), **Sweet/Caring**, **Serious**.
- **39 tools** — app kholna, call karna/uthana/kaatna, SMS bhejna, WhatsApp chat kholna + (Accessibility on ho to) khud Send dabana, notification padhna, screen padhna/tap/type/scroll, alarm, timer, reminder, torch, volume, media control, notes banana/dhundna, baatein yaad rakhna, battery/time, **location pata karna**, **clipboard padhna/likhna**, **web search (DuckDuckGo)**, train status, aur neeche wale naye tools.
- **Macros (sikhe hue routine)** — Darling ko ek routine sikhao, naam do, fir bas naam bolo: `save_macro`, `play_macro`, `list_macros`, `delete_macro`. Steps: open_app, tap_text, type_text, go_back, go_home, wait. Macros phone ke andar private file me save hote hain.
- **SOS** — Boss bas "SOS" / "bachao" bole: Darling emergency contact ko location ke saath SMS karti hai, torch blink karti hai (~10 second) aur usi contact ko call lagati hai (`trigger_sos`). Rukwana ho to `cancel_sos`. Emergency contact ka number pehle Settings me daalna hai.
- **Wake Word** — background service "Hey Darling" / "Darling" sunti rehti hai (Setup me on karo). Battery zyada lagegi.
- **Sirf meri awaaz** — voiceprint enroll karo (Setup screen). Ye basic level ka gate hai, bank-level biometric security nahi.
- **Memory + Notes** — phone ke andar Room database me. Kuch bhi internet par store nahi hota, sirf Gemini API calls jate hain.

## Jo is app me NAHI hai (saaf-saaf)

- **Koi license / activation / paywall / checkout / "genuine check" nahi hai** — app bilkul free aur khula hai, koi server par jaanch nahi hoti.
- **Koi dusri app (Maya) ki branding, code, prompt ya model files isme copy nahi ki gayi hain.** Naye features (macros, SOS, mood) yahan ke apne original code se bane hain.
- Koi Termux coding agent, koi PC-duet call, koi apna server backend nahi hai.

## APK kaise banega (2 raste)

### Rasta A — GitHub se cloud build (PC par kuch install nahi)
1. github.com par free account banao (agar nahi hai).
2. New repository banao, naam: `darling-android` (private rakho).
3. Is ZIP ke andar ki **saari files** repository me upload karo (folder ke andar ka samaan, folder samet nahi). ZIP ka ek hissa workflow file (.github/workflows) bhi hai — use bhi usi jagah rakho.
4. Repository ke **Actions** tab me jao → "Build Darling APK" → **Run workflow**.
5. Build khatm hone par neeche **Artifacts** me `app-debug-apk` milega — download karke ZIP kholo, andar `app-debug.apk` hai.
6. APK phone me bhejo aur install karo (pehli baar "unknown source se install" allow karna padega).

Agar build fail ho to Actions ke red cross wale log ka screenshot bhejo, fix ho jayega.

### Rasta B — Android Studio (PC par)
1. Android Studio install karo, is folder ko project ki tarah kholo.
2. Pehli baar Gradle wrapper chahiye: Terminal me `gradle wrapper --gradle-version 8.9` (ya Studio khud sync kar lega agar system Gradle hai).
3. Phone USB se jodo (USB debugging on) → Run ▶.

## Pehli baar app kholne ke baad (Setup order)

1. **Settings tab** → apni **Gemini API key** daalo (Google AI Studio se free milti hai: aistudio.google.com → Get API key) → **Save + Test karo**. Key sirf phone me encrypted save hoti hai. Chat me kisi ko mat bhejna.
2. **Settings tab** → **Emergency contact number** daalo (SOS ke liye zaroori hai).
3. **Setup tab** → **Permissions do** (mic, call, SMS, contacts, notification, location).
4. **Accessibility Settings kholo** → Darling ko on karo (screen control + WhatsApp auto-send + macros ke liye).
5. **Notification Access kholo** → Darling ko on karo (WhatsApp/SMS message padhne ke liye).
6. **Battery restriction hatao** (wake word service zinda rahe iske liye).
7. Wake word chahiye to **"Wake Word — Hey Darling"** switch on karo.
8. **Sirf meri awaaz** chahiye to switch on karke **Awaaz enroll karo** (shant jagah, 2.5 second bolna hai).
9. Home tab → **🎙 Calling Mode** → bolo: *"Darling, kal 7 baje ka alarm lagao"* / *"WhatsApp par ... ko message karo"* / *"macro sikhao..."* / *"gussa ho jao"*

## Sacchai wali limits (pehle se jaan lo)

- **Wake word trained model wali nahi hai:** Kisi dusri app ka on-device trained wake-word TFLite model yahan dobara nahi ban sakta tha, isliye Darling ka wake word Android ke apne **SpeechRecognizer** par chalta hai — "Hey Darling" / "Darling" sunke jagti hai. Network ya recognizer band ho to kabhi-kabhi miss ho sakta hai; trained model jitna tez/pakka nahi hai.
- **Owner-voice sirf basic gate hai:** Speaker verification yahan apna simple voiceprint hai (convenience gate) — bade trained speaker models (jaise ReDimNet-level) jitna accurate nahi. Paisa/payment jaise kaam is bharose mat karna.
- **Emotion awaaz me Gemini Live ke tone se aata hai:** Darling ke prompts use hasne, naram padne, gussa dikhane ko kehte hain — par awaaz ka asal rang Live model par hai; text chat me emotion shabdon me dikhega, awaaz me nahi.
- **Macros Accessibility par chalte hain:** Dusri app ka design badal jaye to tap wala step kabhi fail ho sakta hai; play_macro har step ka result saaf batata hai, jhoothi success nahi deta.
- **SOS ke liye pehle se taiyari chahiye:** Emergency contact Settings me dala ho, SMS + call + location permissions mile hon — warna jo step nahi ho paya, Darling result me saaf likh ke degi.
- **Normal phone call** Darling utha sakti hai, par Android kisi app ko call ke andar apni digital awaaz nahi daalne deta. To call par "khud baat karna" speakerphone wale raste se hi hoga.
- **WhatsApp** ka koi official control API nahi hai. Chat kholna pakka hai; khud Send dabana Accessibility se hota hai — WhatsApp ka design badle to kabhi fail ho sakta hai.
- **Train status**: Gemini ke paas live data nahi hota. Settings me train API ka URL template (RapidAPI jaisi service) daaloge to Darling waha se fetch karke batayegi; khali chhoda to NTES ki website khol degi. Platform number hamesha "expected" samjho.
- **Web search** DuckDuckGo ke public HTML page par tika hai — page ka layout badla to result khali aa sakta hai, aise me Darling jhooth nahi bolegi, saaf mana karegi.
- Ye **debug APK** personal use ke liye hai. Play Store par dalna hai to pehle privacy policy + Google ki permission declarations lagegi.

## Project structure

- `app/src/main/java/com/zoya/assistant/core` — settings (encrypted), persona/mood prompt, macros storage (package naam purana hi rakha gaya hai taaki code na toote; user ko dikhne wala har naam Darling hai)
- `.../gemini` — Gemini REST chat + 39 tools ka registry (macros, SOS, mood, location, clipboard, web search yahi hain — REST aur Live dono yahi registry istemal karte hain)
- `.../live` — Gemini Live WebSocket voice engine (audio in/out, barge-in, tool calls)
- `.../service` — Accessibility, notification reader, wake word, call receiver, reminder
- `.../voice` — voiceprint enroll/verify
- `.../data` — Room database (notes + memory)
- `.../ui` — saare screens (Home/Calling, Chat, Notes, Setup, Settings)

Version 1.0 — banaya gaya: 2026-10-20
