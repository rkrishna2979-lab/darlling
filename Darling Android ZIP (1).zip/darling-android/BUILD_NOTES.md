# Darling — Build Notes (2026-10-20)

Source: copied from `~/workspace/zoya-android/` (Zoya v2.0, versionCode 2 /
"2.0", jo GitHub Actions par saaf compile hua tha). Original folder
**untouched** hai — saara kaam `~/workspace/darling-android/` me hua.
Gradle yahan chalaya nahi gaya (local Android SDK nahi hai) — sirf static
review, bilkul waise hi jaise Zoya banayi gayi thi.

## Badli hui files
- `settings.gradle.kts` — rootProject.name "Darling"
- `app/build.gradle.kts` — versionCode 1, versionName "1.0"; signing config
  `darlingDebug`, storeFile `darling-debug.keystore`
  (zoya wali keystore ki copy, naye naam se — future Darling builds ek
  dusre par install honge). applicationId / namespace jaan-boojh kar
  `com.zoya.assistant` hi rakha (task ki salah: package rename = risk).
- `.github/workflows/build-apk.yml` — workflow name "Build Darling APK"
- `AndroidManifest.xml` — theme Theme.Darling, services
  DarlingAccessibilityService / DarlingNotificationService, app label
  @string/app_name = "Darling"; NAYI permissions:
  ACCESS_FINE_LOCATION + ACCESS_COARSE_LOCATION (get_location + SOS)
- `res/values/strings.xml` — app_name "Darling", wake strings "Hey Darling"
- `res/values/themes.xml` + `colors.xml` — Theme.Darling, darling_* colors
  (definition + saare references ek saath badle)
- `res/drawable/ic_stat_zoya.xml` -> `ic_stat_darling.xml` (file rename;
  teeno references — WakeWordService, CallReceiver, ReminderReceiver —
  R.drawable.ic_stat_darling par update)

## Rename kiye gaye classes / files
- `ZoyaAccessibilityService.kt` -> `DarlingAccessibilityService.kt`
  (AccessibilityBridge.service type + manifest entry dono match)
- `ZoyaNotificationService.kt` -> `DarlingNotificationService.kt`
  (NotificationStore KDoc reference + manifest entry match)
- `ZoyaTheme`/`ZoyaColorScheme` -> `DarlingTheme`/`DarlingColorScheme`
  (Theme.kt + MainActivity import/use match)
- Baaki saare user-visible "Zoya" strings -> "Darling": VoiceScreen ka
  title "D A R L I N G", nav tab, ChatScreen naam, notification titles,
  wake-word constant WAKE_WORD = "darling" ("hey darling" bhi isi se
  match hota hai kyunki check `contains` hai), settings file naam
  darling_settings(_encrypted), Room DB "darling.db",
  wake lock tag, thread naam, "darling_action" intent extra
  (WakeWordService producer + MainActivity consumer dono badle).

## Persona (core/SettingsStore.kt — pura rewrite)
- `systemInstruction()` ab EK hi jagah se REST chat aur Live voice dono
  ko jata hai (dono clients wahi function call karte hain — verified).
- Naya original Hinglish persona: Darling Boss ko "Boss" bulati hai;
  emotions AAWAAZ aur shabdon me — natural hasi, caring softness,
  tasteful flirty teasing (kabhi explicit nahi), cute nakhra-gussa jo
  ek pyaari baat par pighal jaye, sad/emotional soft mode (rona aane
  wali naram awaaz, jokes band), happy/excited. Boss ka mood hamesha
  upar — mirror rule prompt me saaf likha hai.
- Persona modes (Settings chips): **Flirty** (default), **Sweet**
  (= Sweet/Caring), **Serious**. Purane values auto-map:
  Normal->Flirty, Companion->Sweet (getter aur setter dono me),
  taaki koi purani setting toote nahi.
- Nayi settings: `currentMood` (default "flirty") + `emergencyContact`.

## Naye tools (gemini/ToolRegistry.kt) — kul 39 tools (28 purane + 11 naye)
Declarations aur execute() dono me jode gaye; kyunki REST aur Live
**ek hi** `functionDeclarations()` + `execute()` istemal karte hain
(verified: GeminiRestClient.kt:106/166, LiveSession.kt:234/307),
dual registration apne-aap pakka hai. Programmatic check:
declared 39 / missing execute cases = 0.
1. `save_macro` / `play_macro` / `list_macros` / `delete_macro` —
   storage nayi file `core/MacroStore.kt` (filesDir/darling_macros.json,
   org.json). Verbs: open_app, tap_text, type_text, go_back, go_home,
   wait. Playback ToolRegistry.playMacro me: openApp reuse,
   AccessibilityBridge reuse, har step try/catch + result log,
   delays coroutine delay se (execute suspend hai, whatsappSend wala
   hi pattern).
2. `trigger_sos` / `cancel_sos` — har step apna try/catch:
   lastKnownLocation (GPS/Network/Passive, permission check pehle) ->
   SMS (send_sms wala SmsManager path, bina confirmation — SOS ka
   matlab hi yahi) -> torch blink background Thread par ~10s
   (@Volatile flag, cancel_sos flag off + torch off) -> placeCall
   (CALL_PHONE permission check placeCall ke andar pehle se hai).
   Contact khali ho to SMS/call skip ka saaf note + blink phir bhi.
3. `set_mood` — happy/flirty/caring/angry_pout/sad/serious validate
   karke SettingsStore.currentMood me save; systemInstruction()
   har session me moodLine() inject karta hai (REST + Live dono).
4. `get_location` — lastKnownLocation reuse, Maps link ke saath.
5. `read_clipboard` / `set_clipboard` — ClipboardManager, koi nayi
   permission nahi.
6. `search_web` — DuckDuckGo html endpoint, maujooda OkHttp `http`
   client se (trainStatus wala pattern), result__a regex parse +
   uddg redirect decode, top 5 title+link text me.

Settings UI: SettingsScreen me "Emergency contact (SOS)" field
(saveAll me persist) + personality chips Flirty/Sweet/Serious.
SetupScreen: permission launcher me FINE+COARSE location joda,
wake-word label "Hey Darling".

## Jo NAHI dala (README me bhi likha hai)
- Koi license/activation/paywall/checkout/"genuine check" code ya naam — bilkul nahi.
- Maya ki branding, code, prompt text ya TFLite models — kuch copy nahi;
  persona aur saare naye features original likhe gaye hain.
- On-device trained wake-word model dobara nahi ban sakta — SpeechRecognizer
  wala wake service hi "Hey Darling" naam se chalta hai.
- Termux coding agent, PC-duet, server backend, wallpaper tool — nahi dala.

## Grep quality gate (final)
`grep -rIn "Zoya|zoya|ZOYA"` pure darling-android tree par (keystore
binary chhod kar), package `com.zoya.assistant` / path `com/zoya/assistant`
ko chhod kar:
- **User-visible leftover: 0.**
- Sirf 2 allowed bache: (1) package naam har jagah (jaan-boojh kar rakha),
  (2) SettingsStore.kt:82 par ek comment "Old Zoya-era values are
  mapped..." — origin/migration samjhane wala comment, task ke hisaab
  se allowed.
- Brace balance: har .kt file me { } gin kar barabar (MacroStore 33/33,
  ToolRegistry 255/255, SettingsStore 19/19, baaki sab unchanged-balance).
  ToolRegistry ke raw paren count me 8 ka farak sirf comments ke
  "1) 2)" numbering aur multi-line statements ki wajah se hai —
  diff par line-by-line jaanch karke confirm kiya, code paren sab band hain.

## Double-check kiye gaye risk spots
- SOS function ka if/else structure haath se theek kiya gaya tha
  (ek galat dusra `else` jud gaya tha) — pura function dobara padh
  kar verify kiya: if-blank / else(SMS->blink->call) / if-blank(blink),
  braces sahi.
- `lastKnownLocation` me smart-cast trap: `best` mutable var ko
  `currentBest` local val me leke compare kiya — compile-safe.
- `searchWeb` me `use {}` lambda ke andar bare `return` — `use` inline
  function hai, isliye non-local return valid Kotlin hai aur response
  close hona finally se pakka hai; trainStatus wala hi HTTP client hai.
- Manifest service naam vs class file naam: DarlingAccessibilityService.kt
  me `class DarlingAccessibilityService`, DarlingNotificationService.kt me
  `class DarlingNotificationService` — manifest `.service.` entries se match.
- ToolRegistry.createReminder ka hardcoded ComponentName
  "com.zoya.assistant.service.ReminderReceiver" — ReminderReceiver ka
  naam NAHI badla, isliye ye string bhi sahi rehti hai.
- MacroStore: `lowercase()` no-arg (locale-safe, codebase me pehle se
  yahi pattern hai), `list + element`, org.json imports — sab maujooda
  dependencies ke andar hain. Koi nayi dependency NAHI jodi gayi.
- SettingsStore.systemInstruction() ke raw string (`"""`) ke andar
  koi `${` ya `"""` sequence nahi hai; sirf do template — $tone aur
  ${moodLine()} — dono defined hain.
