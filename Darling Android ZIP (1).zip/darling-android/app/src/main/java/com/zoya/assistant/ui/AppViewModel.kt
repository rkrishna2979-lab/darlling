package com.zoya.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zoya.assistant.core.SettingsStore
import com.zoya.assistant.data.AppDatabase
import com.zoya.assistant.data.MemoryItem
import com.zoya.assistant.data.Note
import com.zoya.assistant.gemini.ChatMsg
import com.zoya.assistant.gemini.GeminiRestClient
import com.zoya.assistant.gemini.ToolRegistry
import com.zoya.assistant.live.LiveSession
import com.zoya.assistant.voice.VoicePrintManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject

class AppViewModel(app: Application) : AndroidViewModel(app) {

    val settings: SettingsStore = SettingsStore(app)
    private val db: AppDatabase = AppDatabase.get(app)
    val tools: ToolRegistry = ToolRegistry(app, settings)
    private val rest: GeminiRestClient = GeminiRestClient(settings, tools)
    private val voicePrint: VoicePrintManager = VoicePrintManager(app)

    // ---------- Chat ----------
    private val _chat = MutableStateFlow<List<ChatMsg>>(emptyList())
    val chat: StateFlow<List<ChatMsg>> = _chat
    private val _thinking = MutableStateFlow(false)
    val thinking: StateFlow<Boolean> = _thinking

    fun sendChat(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _thinking.value) return
        _chat.value = _chat.value + ChatMsg("user", trimmed)
        _thinking.value = true
        viewModelScope.launch {
            try {
                val reply = rest.send(_chat.value)
                _chat.value = _chat.value + ChatMsg("model", reply)
            } catch (e: Exception) {
                _chat.value = _chat.value + ChatMsg("model", "Error: ${e.message ?: "kuch gadbad ho gayi"}")
            } finally {
                _thinking.value = false
            }
        }
    }

    fun clearChat() {
        _chat.value = emptyList()
    }

    // ---------- Live voice ----------
    private val _liveState = MutableStateFlow("STOPPED")
    val liveState: StateFlow<String> = _liveState
    private val _liveLevel = MutableStateFlow(0f)
    val liveLevel: StateFlow<Float> = _liveLevel
    private val _liveUserText = MutableStateFlow("")
    val liveUserText: StateFlow<String> = _liveUserText
    private val _liveModelText = MutableStateFlow("")
    val liveModelText: StateFlow<String> = _liveModelText
    private val _liveError = MutableStateFlow("")
    val liveError: StateFlow<String> = _liveError

    private var liveSession: LiveSession? = null

    private fun ensureLive(): LiveSession {
        if (liveSession == null) {
            liveSession = LiveSession(getApplication(), settings, tools, object : LiveSession.Listener {
                override fun onState(state: String) { _liveState.value = state }
                override fun onLevel(level: Float) { _liveLevel.value = level }
                override fun onUserTranscript(text: String) { _liveUserText.value = text }
                override fun onModelTranscript(text: String) { _liveModelText.value = text }
                override fun onError(message: String) {
                    _liveState.value = "ERROR"
                    _liveError.value = message
                }
            })
        }
        return liveSession!!
    }

    fun startLive() {
        if (settings.apiKey.isBlank()) {
            _liveState.value = "ERROR"
            _liveError.value = "Pehle Settings me Gemini API key daalo."
            return
        }
        _liveUserText.value = ""
        _liveModelText.value = ""
        _liveError.value = ""
        ensureLive().start()
    }

    fun stopLive() {
        liveSession?.stop()
        _liveState.value = "STOPPED"
        _liveLevel.value = 0f
        _liveError.value = ""
    }

    fun interruptLive() {
        liveSession?.interrupt()
    }

    // ---------- Tools (quick actions) ----------
    private val _toolResult = MutableStateFlow("")
    val toolResult: StateFlow<String> = _toolResult

    fun runTool(name: String, argsJson: String) {
        viewModelScope.launch {
            _toolResult.value = "Chal raha hai: $name ..."
            _toolResult.value = try {
                tools.execute(name, JSONObject(argsJson))
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        }
    }

    // ---------- Notes ----------
    val notes: StateFlow<List<Note>> = db.noteDao().getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addNote(title: String, content: String) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            db.noteDao().insert(
                Note(title = title.ifBlank { "Note" }, content = content, createdAt = now, updatedAt = now)
            )
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch { db.noteDao().delete(note) }
    }

    // ---------- Memory ----------
    val memories: StateFlow<List<MemoryItem>> = db.memoryDao().getAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteMemory(item: MemoryItem) {
        viewModelScope.launch { db.memoryDao().delete(item) }
    }

    fun clearMemories() {
        viewModelScope.launch { db.memoryDao().clear() }
    }

    // ---------- API key test ----------
    private val _apiTest = MutableStateFlow("")
    val apiTest: StateFlow<String> = _apiTest

    fun testApiKey() {
        viewModelScope.launch {
            _apiTest.value = "Test ho raha hai..."
            val (ok, msg) = try {
                rest.testKey()
            } catch (e: Exception) {
                false to (e.message ?: "error")
            }
            _apiTest.value = if (ok) "API key sahi hai ✓ ($msg)" else "API key fail ✗ ($msg)"
        }
    }

    // ---------- Voiceprint ----------
    private val _voiceStatus = MutableStateFlow(
        if (voicePrint.isEnrolled()) "Voiceprint enrolled hai ✓" else "Voiceprint enrolled nahi hai"
    )
    val voiceStatus: StateFlow<String> = _voiceStatus

    fun enrollVoice() {
        viewModelScope.launch {
            _voiceStatus.value = "Bolo… record ho raha hai"
            _voiceStatus.value = try {
                voicePrint.enroll()
                "Enroll ho gaya ✓"
            } catch (e: Exception) {
                "Enroll fail: ${e.message}"
            }
        }
    }

    fun verifyVoice() {
        viewModelScope.launch {
            _voiceStatus.value = "Sun rahi hu... bolo"
            _voiceStatus.value = try {
                val (ok, score) = voicePrint.verify()
                if (ok) "Match ho gaya ✓ (score ${"%.2f".format(score)})"
                else "Match nahi hua ✗ (score ${"%.2f".format(score)})"
            } catch (e: Exception) {
                "Verify fail: ${e.message}"
            }
        }
    }

    override fun onCleared() {
        liveSession?.stop()
        super.onCleared()
    }
}
