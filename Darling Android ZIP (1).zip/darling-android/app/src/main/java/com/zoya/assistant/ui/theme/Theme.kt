package com.zoya.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Darling's futuristic dark palette: deep space background, cyan voice glow. */
private val DarlingColorScheme = darkColorScheme(
    primary = Color(0xFF22D3EE),
    onPrimary = Color(0xFF00131A),
    secondary = Color(0xFF67E8F9),
    onSecondary = Color(0xFF00131A),
    background = Color(0xFF050914),
    onBackground = Color(0xFFE6F6FF),
    surface = Color(0xFF0B1220),
    onSurface = Color(0xFFE6F6FF),
    surfaceVariant = Color(0xFF111C30),
    onSurfaceVariant = Color(0xFFB8D4E3),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF2B0000)
)

@Composable
fun DarlingTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarlingColorScheme,
        content = content
    )
}
