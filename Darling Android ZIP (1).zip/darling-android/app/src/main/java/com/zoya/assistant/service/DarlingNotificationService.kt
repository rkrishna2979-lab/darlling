package com.zoya.assistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Captures incoming notifications (WhatsApp, SMS apps, etc.) into
 * [NotificationStore] so Darling can read the user's latest messages aloud
 * and reply through the notification's own inline reply action.
 *
 * Requires the user to grant Notification Access for Darling in system
 * settings; nothing is captured until then.
 */
class DarlingNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handlePosted(sbn)
        } catch (e: Exception) {
            // A malformed notification from any app must never crash us.
        }
    }

    private fun handlePosted(sbn: StatusBarNotification) {
        // Skip our own notifications.
        if (sbn.packageName == packageName) return

        val notification = sbn.notification ?: return

        // Skip ongoing notifications (media playback, calls in progress…).
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return

        val extras = notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: extras.getString(Notification.EXTRA_TITLE)
            ?: ""

        // Choose the longest available body text.
        val candidates = listOfNotNull(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString(),
            extras.getString(Notification.EXTRA_TEXT)
        )
        val text = candidates.maxByOrNull { it.length }?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val appLabel = try {
            val info = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        // Find an inline reply action, if the posting app offers one.
        var replyPair: Pair<PendingIntent, RemoteInput>? = null
        val actions = notification.actions
        if (actions != null) {
            for (action in actions) {
                val inputs = action.remoteInputs
                val intent = action.actionIntent
                if (inputs != null && inputs.isNotEmpty() && intent != null) {
                    replyPair = Pair(intent, inputs[0])
                    break
                }
            }
        }

        NotificationStore.add(
            IncomingMsg(
                packageName = sbn.packageName,
                appLabel = appLabel,
                title = title.trim(),
                text = text,
                time = sbn.postTime
            ),
            sbn.key,
            replyPair
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        // No-op: messages already captured stay available in the store.
    }
}
