package com.zoya.assistant.core

/**
 * Central endpoints for the Gemini APIs.
 *
 * Model names deliberately do NOT live here: they are user-editable
 * settings (see [SettingsStore.liveModel] / [SettingsStore.chatModel]),
 * so a model rename never needs a code change.
 */
object AppConfig {

    /** Base URL for the Gemini REST API (v1beta models endpoint hangs off this). */
    const val REST_BASE: String = "https://generativelanguage.googleapis.com/"

    /** Gemini Live API bidirectional WebSocket endpoint. */
    const val LIVE_WS_URL: String =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
}
