package com.zoya.assistant.service

/**
 * Static bridge between the rest of the app and [DarlingAccessibilityService].
 *
 * The accessibility service registers itself here when it connects and
 * unregisters when it is destroyed. Every function is safe to call when the
 * service is not enabled: reads return an empty string and actions return
 * false, so callers never need to null-check the service themselves.
 */
object AccessibilityBridge {

    @Volatile
    var service: DarlingAccessibilityService? = null

    fun isEnabled(): Boolean = service != null

    fun readScreenText(): String = service?.readScreenText() ?: ""

    fun tapByText(text: String): Boolean = service?.tapByText(text) ?: false

    fun typeText(text: String): Boolean = service?.typeText(text) ?: false

    fun pressKey(key: String): Boolean = service?.pressKey(key) ?: false

    fun scrollForward(): Boolean = service?.scrollForward() ?: false

    fun tapSendButton(): Boolean = service?.tapSendButton() ?: false
}
