package com.zoya.assistant.gemini

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.zoya.assistant.core.MacroStore
import com.zoya.assistant.core.SettingsStore
import com.zoya.assistant.data.AppDatabase
import com.zoya.assistant.data.MemoryItem
import com.zoya.assistant.data.Note
import com.zoya.assistant.service.AccessibilityBridge
import com.zoya.assistant.service.NotificationStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Every action Darling can perform on the phone, exposed to Gemini as function
 * declarations.
 *
 * Honesty rule: a tool returns success ONLY when the action really happened
 * (or, for taps it cannot verify, it says exactly that). Missing permissions
 * or settings produce a clear error string the model can read out to the user.
 */
class ToolRegistry(
    private val context: Context,
    private val settings: SettingsStore
) {

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /** Saved macros (taught routines), persisted in filesDir. */
    private val macroStore: MacroStore by lazy { MacroStore(context) }

    /** True while an SOS torch blink is running on its background thread. */
    @Volatile
    private var sosBlinkActive: Boolean = false

    // ------------------------------------------------------------------
    // Function declarations
    // ------------------------------------------------------------------

    fun functionDeclarations(): JSONArray {
        val arr = JSONArray()
        fun prop(type: String, desc: String): JSONObject =
            JSONObject().put("type", type).put("description", desc)

        fun decl(
            name: String,
            description: String,
            properties: JSONObject,
            required: List<String> = emptyList()
        ) {
            val params = JSONObject()
                .put("type", "OBJECT")
                .put("properties", properties)
            if (required.isNotEmpty()) params.put("required", JSONArray(required))
            arr.put(
                JSONObject()
                    .put("name", name)
                    .put("description", description)
                    .put("parameters", params)
            )
        }

        val str = { d: String -> prop("STRING", d) }
        val int = { d: String -> prop("INTEGER", d) }
        val bool = { d: String -> prop("BOOLEAN", d) }
        val noParams = JSONObject()

        decl("open_app", "Open an installed app by its name (e.g. 'YouTube') or package name.",
            JSONObject().put("query", str("App name or package name")), listOf("query"))
        decl("open_url", "Open a web page URL in the browser.",
            JSONObject().put("url", str("Full URL, e.g. https://example.com")), listOf("url"))
        decl("set_alarm", "Set a device alarm using the clock app.",
            JSONObject()
                .put("hour", int("Hour 0-23"))
                .put("minute", int("Minute 0-59"))
                .put("label", str("Alarm label (optional)")),
            listOf("hour", "minute"))
        decl("set_timer", "Start a countdown timer in the clock app.",
            JSONObject()
                .put("minutes", int("Timer length in minutes"))
                .put("label", str("Timer label (optional)")),
            listOf("minutes"))
        decl("create_reminder", "Create a reminder that will notify the user after a delay. Use for 'remind me in X minutes to ...'.",
            JSONObject()
                .put("title", str("What to remind about"))
                .put("delay_minutes", int("Minutes from now")),
            listOf("title", "delay_minutes"))
        decl("toggle_flashlight", "Turn the phone flashlight (torch) on or off.",
            JSONObject().put("on", bool("true = on, false = off")), listOf("on"))
        decl("set_volume", "Set the media volume as a percentage (0-100).",
            JSONObject().put("percent", int("Volume percent 0-100")), listOf("percent"))
        decl("media_control", "Control media playback. action is one of: play_pause, next, previous.",
            JSONObject().put("action", str("play_pause | next | previous")), listOf("action"))
        decl("call_number", "Make a phone call to a number.",
            JSONObject().put("number", str("Phone number to call")), listOf("number"))
        decl("call_contact", "Make a phone call to a saved contact by name.",
            JSONObject().put("name", str("Contact name")), listOf("name"))
        decl("send_sms", "Send an SMS text message. If confirmation is required, the first call returns CONFIRM_REQUIRED; ask the user, then call again with confirmed=true.",
            JSONObject()
                .put("number", str("Destination phone number"))
                .put("message", str("Message text"))
                .put("confirmed", bool("Set true only after the user explicitly confirmed sending")),
            listOf("number", "message"))
        decl("whatsapp_open", "Open a WhatsApp chat for a phone number or contact name, optionally with a pre-filled (unsent) message.",
            JSONObject()
                .put("number_or_name", str("Phone number or contact name"))
                .put("message", str("Pre-filled message text (optional)")),
            listOf("number_or_name"))
        decl("whatsapp_send", "Send a WhatsApp message: opens the chat and taps Send via the accessibility service. If confirmation is required, the first call returns CONFIRM_REQUIRED; ask the user, then call again with confirmed=true.",
            JSONObject()
                .put("number_or_name", str("Phone number or contact name"))
                .put("message", str("Message text"))
                .put("confirmed", bool("Set true only after the user explicitly confirmed sending")),
            listOf("number_or_name", "message"))
        decl("read_notifications", "Read the most recent captured notifications (WhatsApp, SMS and other apps).", noParams)
        decl("read_screen", "Read the text currently visible on the phone screen (needs the accessibility service).", noParams)
        decl("tap_text", "Tap a visible UI element by its text on the current screen (needs accessibility).",
            JSONObject().put("text", str("Visible text to tap")), listOf("text"))
        decl("type_text", "Type text into the currently focused text field (needs accessibility).",
            JSONObject().put("text", str("Text to type")), listOf("text"))
        decl("press_key", "Press a system navigation key: back, home or recents (needs accessibility).",
            JSONObject().put("key", str("back | home | recents")), listOf("key"))
        decl("scroll_screen", "Scroll the current screen forward (needs accessibility).", noParams)
        decl("create_note", "Save a note in Darling's notes.",
            JSONObject()
                .put("title", str("Note title"))
                .put("content", str("Note content")),
            listOf("title", "content"))
        decl("search_notes", "Search Darling's saved notes by keyword.",
            JSONObject().put("query", str("Search words")), listOf("query"))
        decl("remember_fact", "Save a long-term fact about the user (preferences, names, details) to memory.",
            JSONObject()
                .put("key", str("Short key, e.g. 'wife name'"))
                .put("value", str("The fact to remember")),
            listOf("key", "value"))
        decl("recall_facts", "Read all long-term facts saved in memory.", noParams)
        decl("train_status", "Get live running status of an Indian Railways train by train number or name. Expected arrival/departure/platform come from the configured train data source; platform can change at the last minute.",
            JSONObject().put("train", str("Train number or name")), listOf("train"))
        decl("answer_call", "Answer the currently ringing normal phone call.", noParams)
        decl("reject_call", "Reject/end the current normal phone call.", noParams)
        decl("get_datetime", "Get the current date and time on the phone.", noParams)
        decl("get_battery", "Get the current battery percentage of the phone.", noParams)

        // -- Macros (taught routines) -----------------------------------
        decl("save_macro", "Save a named routine (macro) that Darling can replay later with play_macro. steps_json is a JSON array of steps, each step an object: {\"verb\":\"open_app|tap_text|type_text|go_back|go_home|wait\", \"text\":\"...\", \"seconds\":2}. Example: [{\"verb\":\"open_app\",\"text\":\"YouTube\"},{\"verb\":\"wait\",\"seconds\":3},{\"verb\":\"tap_text\",\"text\":\"Search\"}].",
            JSONObject()
                .put("name", str("Macro name, e.g. 'morning routine'"))
                .put("steps_json", str("JSON array of steps as described")),
            listOf("name", "steps_json"))
        decl("play_macro", "Replay a saved macro (routine) by name, step by step.",
            JSONObject().put("name", str("Macro name")), listOf("name"))
        decl("list_macros", "List all saved macros (routines) with their steps.", noParams)
        decl("delete_macro", "Delete a saved macro by name.",
            JSONObject().put("name", str("Macro name")), listOf("name"))

        // -- SOS ----------------------------------------------------------
        decl("trigger_sos", "EMERGENCY: trigger an SOS right now. Sends an SOS SMS with the phone's location to the emergency contact saved in Settings, starts the torch blinking, and calls that contact. Use the moment the user says SOS / help / bachao / emergency — do not ask for confirmation first.", noParams)
        decl("cancel_sos", "Cancel an active SOS: stops the torch blinking and turns the torch off.", noParams)

        // -- Mood ---------------------------------------------------------
        decl("set_mood", "Change Darling's own emotional mood. Use when the user asks her to be in a mood, e.g. 'gussa ho jao', 'khush ho jao', 'serious ho jao', 'pyar se bolo'. mood is one of: happy, flirty, caring, angry_pout, sad, serious.",
            JSONObject().put("mood", str("happy | flirty | caring | angry_pout | sad | serious")),
            listOf("mood"))

        // -- Location / clipboard / web ------------------------------------
        decl("get_location", "Get the phone's last known location (latitude/longitude plus a Google Maps link).", noParams)
        decl("read_clipboard", "Read the current text from the phone clipboard.", noParams)
        decl("set_clipboard", "Copy a text to the phone clipboard.",
            JSONObject().put("text", str("Text to copy")), listOf("text"))
        decl("search_web", "Search the web (DuckDuckGo) and return the top result titles and links as text.",
            JSONObject().put("query", str("Search query")), listOf("query"))

        return arr
    }

    // ------------------------------------------------------------------
    // Execution
    // ------------------------------------------------------------------

    suspend fun execute(name: String, args: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(args.getString("query"))
                "open_url" -> openUrl(args.getString("url"))
                "set_alarm" -> setAlarm(args.getInt("hour"), args.getInt("minute"), args.optString("label"))
                "set_timer" -> setTimer(args.getInt("minutes"), args.optString("label"))
                "create_reminder" -> createReminder(args.getString("title"), args.getInt("delay_minutes"))
                "toggle_flashlight" -> toggleFlashlight(args.getBoolean("on"))
                "set_volume" -> setVolume(args.getInt("percent"))
                "media_control" -> mediaControl(args.getString("action"))
                "call_number" -> placeCall(args.getString("number"))
                "call_contact" -> callContact(args.getString("name"))
                "send_sms" -> sendSms(args.getString("number"), args.getString("message"), args.optBoolean("confirmed", false))
                "whatsapp_open" -> openWhatsAppChat(args.getString("number_or_name"), args.optString("message")).second
                "whatsapp_send" -> whatsappSend(args.getString("number_or_name"), args.getString("message"), args.optBoolean("confirmed", false))
                "read_notifications" -> readNotifications()
                "read_screen" -> readScreen()
                "tap_text" -> tapText(args.getString("text"))
                "type_text" -> typeText(args.getString("text"))
                "press_key" -> pressKeyTool(args.getString("key"))
                "scroll_screen" -> scrollScreen()
                "create_note" -> createNote(args.getString("title"), args.getString("content"))
                "search_notes" -> searchNotes(args.getString("query"))
                "remember_fact" -> rememberFact(args.getString("key"), args.getString("value"))
                "recall_facts" -> recallFacts()
                "train_status" -> trainStatus(args.getString("train"))
                "answer_call" -> answerCall()
                "reject_call" -> rejectCall()
                "get_datetime" -> getDateTime()
                "get_battery" -> getBattery()
                "save_macro" -> saveMacro(args.getString("name"), args.getString("steps_json"))
                "play_macro" -> playMacro(args.getString("name"))
                "list_macros" -> listMacros()
                "delete_macro" -> deleteMacro(args.getString("name"))
                "trigger_sos" -> triggerSos()
                "cancel_sos" -> cancelSos()
                "set_mood" -> setMood(args.getString("mood"))
                "get_location" -> getLocationText()
                "read_clipboard" -> readClipboard()
                "set_clipboard" -> setClipboard(args.getString("text"))
                "search_web" -> searchWeb(args.getString("query"))
                else -> "ERROR: unknown tool '$name'."
            }
        } catch (e: Exception) {
            "ERROR: tool $name failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun startActivity(intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------
    // Apps / URLs
    // ------------------------------------------------------------------

    private fun openApp(query: String): String {
        val pm = context.packageManager
        val q = query.trim()
        if (q.isBlank()) return "ERROR: no app name given."

        // Treat dotted query as a package name first.
        if (q.contains(".") && !q.contains(" ")) {
            val intent = pm.getLaunchIntentForPackage(q)
            if (intent != null) {
                return if (startActivity(intent)) "Opened app $q."
                else "ERROR: could not launch $q."
            }
        }
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull { info ->
            pm.getApplicationLabel(info).toString().contains(q, ignoreCase = true)
        } ?: return "ERROR: no installed app matching '$q' was found."
        val label = pm.getApplicationLabel(match).toString()
        val intent = pm.getLaunchIntentForPackage(match.packageName)
            ?: return "ERROR: app '$label' has no launchable screen."
        return if (startActivity(intent)) "Opened $label."
        else "ERROR: could not launch $label."
    }

    private fun openUrl(url: String): String {
        var u = url.trim()
        if (u.isBlank()) return "ERROR: no URL given."
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(u))
        return if (startActivity(intent)) "Opened $u in the browser."
        else "ERROR: no browser/app could open $u."
    }

    // ------------------------------------------------------------------
    // Clock: alarms, timers, reminders
    // ------------------------------------------------------------------

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        if (hour !in 0..23 || minute !in 0..59) return "ERROR: invalid alarm time $hour:$minute."
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        return if (startActivity(intent)) {
            "Alarm screen opened for %02d:%02d%s. The user should confirm it in the clock app."
                .format(hour, minute, if (label.isNotBlank()) " ($label)" else "")
        } else "ERROR: no clock app found to set the alarm."
    }

    private fun setTimer(minutes: Int, label: String): String {
        if (minutes <= 0) return "ERROR: timer minutes must be positive."
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
            if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        return if (startActivity(intent)) "Timer screen opened for $minutes minutes."
        else "ERROR: no clock app found to set the timer."
    }

    private fun createReminder(title: String, delayMinutes: Int): String {
        if (delayMinutes <= 0) return "ERROR: reminder delay must be at least 1 minute."
        val triggerAt = System.currentTimeMillis() + delayMinutes * 60_000L
        val intent = Intent().apply {
            component = ComponentName(context, "com.zoya.assistant.service.ReminderReceiver")
            putExtra("title", title)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            (triggerAt / 1000).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exactAllowed = Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms()
        if (exactAllowed) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        } else if (Build.VERSION.SDK_INT >= 23) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        }
        val whenText = SimpleDateFormat("hh:mm a, dd MMM", Locale.getDefault()).format(Date(triggerAt))
        val modeNote = if (exactAllowed) "" else " (approximate time: exact-alarm permission is off in system settings)"
        return "Reminder set for $whenText: \"$title\"$modeNote."
    }

    // ------------------------------------------------------------------
    // Device controls
    // ------------------------------------------------------------------

    private fun toggleFlashlight(on: Boolean): String {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            val chars = cameraManager.getCameraCharacteristics(id)
            val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            val isBack = chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            hasFlash && isBack
        } ?: cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "ERROR: this phone has no camera flash."
        cameraManager.setTorchMode(cameraId, on)
        return if (on) "Flashlight turned on." else "Flashlight turned off."
    }

    private fun setVolume(percent: Int): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val clamped = percent.coerceIn(0, 100)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * clamped / 100.0).roundToInt()
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        val now = (audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100.0 / max).roundToInt()
        return "Media volume set to about $now%."
    }

    private fun mediaControl(action: String): String {
        val keyCode = when (action.trim().lowercase()) {
            "play_pause", "play", "pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "ERROR: unknown media action '$action'. Use play_pause, next or previous."
        }
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return "Media command sent: $action. (Sent to the active media app; playback state itself is not verified.)"
    }

    // ------------------------------------------------------------------
    // Calls & SMS
    // ------------------------------------------------------------------

    private fun placeCall(number: String): String {
        val n = number.trim()
        if (n.isBlank()) return "ERROR: no phone number given."
        if (!hasPermission(Manifest.permission.CALL_PHONE)) {
            return "ERROR: phone-call permission (CALL_PHONE) is not granted. Ask the user to allow the Phone permission for Darling in system Settings."
        }
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n)))
        return if (startActivity(intent)) "Calling $n now."
        else "ERROR: could not start the call to $n."
    }

    /** Finds the first phone number for a contact whose display name contains [name]. */
    private fun findContactPhone(name: String): Pair<String, String>? {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return null
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        context.contentResolver.query(
            uri, projection,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val display = cursor.getString(0) ?: name
                val number = cursor.getString(1) ?: return null
                return display to number
            }
        }
        return null
    }

    private fun callContact(name: String): String {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            return "ERROR: contacts permission (READ_CONTACTS) is not granted. Ask the user to allow Contacts permission for Darling."
        }
        val found = findContactPhone(name)
            ?: return "ERROR: no contact found matching '$name'."
        return placeCall(found.second) + " (contact: ${found.first})"
    }

    private fun sendSms(number: String, message: String, confirmed: Boolean): String {
        if (!hasPermission(Manifest.permission.SEND_SMS)) {
            return "ERROR: SMS permission (SEND_SMS) is not granted. Ask the user to allow SMS permission for Darling."
        }
        if (settings.confirmBeforeSend && !confirmed) {
            return "CONFIRM_REQUIRED: About to send SMS to $number with text: \"$message\". " +
                "Ask the user to confirm out loud; only if they say yes, call send_sms again with confirmed=true."
        }
        val sms: SmsManager? = if (Build.VERSION.SDK_INT >= 31) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION") SmsManager.getDefault()
        }
        if (sms == null) return "ERROR: SMS service is not available on this phone."
        val parts = sms.divideMessage(message)
        if (parts.size > 1) {
            sms.sendMultipartTextMessage(number, null, parts, null, null)
        } else {
            sms.sendTextMessage(number, null, message, null, null)
        }
        return "SMS handed to the phone's SMS service for $number. (Handed over successfully; final delivery depends on the network.)"
    }

    // ------------------------------------------------------------------
    // WhatsApp
    // ------------------------------------------------------------------

    /** Normalises to international digits, defaulting 10-digit Indian numbers to 91-prefixed. */
    private fun normalisePhone(raw: String): String? {
        var digits = raw.filter { it.isDigit() }
        if (digits.startsWith("0") && digits.length == 11) digits = digits.drop(1)
        return when {
            digits.length == 10 -> "91$digits"
            digits.length == 12 && digits.startsWith("91") -> digits
            digits.length in 11..15 -> digits
            else -> null
        }
    }

    private fun isWhatsAppInstalled(): Boolean = try {
        context.packageManager.getPackageInfo("com.whatsapp", 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Returns (success, resultString). */
    private fun openWhatsAppChat(numberOrName: String, message: String): Pair<Boolean, String> {
        if (!isWhatsAppInstalled()) {
            return false to "ERROR: WhatsApp is not installed on this phone."
        }
        val input = numberOrName.trim()
        var digits = normalisePhone(input)
        var resolvedName: String? = null
        if (digits == null) {
            // Treat the input as a contact name.
            if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
                return false to "ERROR: '$input' is not a phone number and contacts permission (READ_CONTACTS) is not granted, so the contact cannot be looked up."
            }
            val found = findContactPhone(input)
                ?: return false to "ERROR: no contact found matching '$input', and it is not a valid phone number."
            resolvedName = found.first
            digits = normalisePhone(found.second)
                ?: return false to "ERROR: the saved number for ${found.first} (${found.second}) is not a valid WhatsApp number."
        }
        val url = buildString {
            append("https://wa.me/").append(digits)
            if (message.isNotBlank()) {
                append("?text=").append(URLEncoder.encode(message, "UTF-8"))
            }
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            setPackage("com.whatsapp")
        }
        val who = resolvedName ?: digits
        return if (startActivity(intent)) {
            true to "WhatsApp chat opened for $who${if (message.isNotBlank()) " with the message pre-filled (not sent yet)" else ""}."
        } else {
            false to "ERROR: could not open the WhatsApp chat for $who."
        }
    }

    private suspend fun whatsappSend(numberOrName: String, message: String, confirmed: Boolean): String {
        if (settings.confirmBeforeSend && !confirmed) {
            return "CONFIRM_REQUIRED: About to send WhatsApp message to $numberOrName with text: \"$message\". " +
                "Ask the user to confirm out loud; only if they say yes, call whatsapp_send again with confirmed=true."
        }
        if (!AccessibilityBridge.isEnabled()) {
            return "ERROR: Darling Accessibility is not enabled, so the Send button cannot be tapped automatically. " +
                "Ask the user to enable it: Settings > Accessibility > Installed apps > Darling."
        }
        val (opened, openResult) = openWhatsAppChat(numberOrName, message)
        if (!opened) return openResult
        delay(3000)
        repeat(3) { attempt ->
            if (AccessibilityBridge.tapSendButton()) {
                return "WhatsApp send button tapped for $numberOrName (attempt ${attempt + 1}). " +
                    "The message should now be sent, but delivery ticks were not verified."
            }
            if (attempt < 2) delay(800)
        }
        return "ERROR: the chat was opened but the WhatsApp Send button was not found on screen after 3 tries. The message was NOT sent."
    }

    // ------------------------------------------------------------------
    // Notifications & screen (accessibility)
    // ------------------------------------------------------------------

    private fun readNotifications(): String {
        val text = NotificationStore.latestText(10)
        return if (text.isBlank()) {
            "No recent notifications captured yet. (Darling needs Notification Access enabled in system Settings to read incoming messages.)"
        } else text
    }

    private fun accessibilityError(): String =
        "ERROR: Darling Accessibility is not enabled. Ask the user to enable it: Settings > Accessibility > Installed apps > Darling."

    private fun readScreen(): String {
        if (!AccessibilityBridge.isEnabled()) return accessibilityError()
        val text = AccessibilityBridge.readScreenText()
        return if (text.isBlank()) "The current screen has no readable text." else text
    }

    private fun tapText(text: String): String {
        if (!AccessibilityBridge.isEnabled()) return accessibilityError()
        return if (AccessibilityBridge.tapByText(text)) "Tapped the element with text \"$text\"."
        else "ERROR: no tappable element with text \"$text\" was found on the current screen."
    }

    private fun typeText(text: String): String {
        if (!AccessibilityBridge.isEnabled()) return accessibilityError()
        return if (AccessibilityBridge.typeText(text)) "Typed \"$text\" into the focused field."
        else "ERROR: could not type — no editable field is focused on screen."
    }

    private fun pressKeyTool(key: String): String {
        val k = key.trim().lowercase()
        if (k !in listOf("back", "home", "recents")) {
            return "ERROR: key must be one of: back, home, recents."
        }
        if (!AccessibilityBridge.isEnabled()) return accessibilityError()
        return if (AccessibilityBridge.pressKey(k)) "Pressed $k."
        else "ERROR: pressing $k failed."
    }

    private fun scrollScreen(): String {
        if (!AccessibilityBridge.isEnabled()) return accessibilityError()
        return if (AccessibilityBridge.scrollForward()) "Scrolled forward."
        else "ERROR: nothing scrollable was found on the current screen."
    }

    // ------------------------------------------------------------------
    // Notes & memory (Room)
    // ------------------------------------------------------------------

    private suspend fun createNote(title: String, content: String): String {
        val now = System.currentTimeMillis()
        AppDatabase.get(context).noteDao().insert(
            Note(title = title, content = content, createdAt = now, updatedAt = now)
        )
        return "Note saved: \"$title\"."
    }

    private suspend fun searchNotes(query: String): String {
        val dao = AppDatabase.get(context).noteDao()
        val notes: List<Note> = try {
            dao.search(query).first()
        } catch (e: Exception) {
            try {
                dao.getAll().first().filter {
                    it.title.contains(query, ignoreCase = true) || it.content.contains(query, ignoreCase = true)
                }
            } catch (e2: Exception) {
                return "ERROR: could not read notes: ${e2.message ?: "database error"}"
            }
        }
        if (notes.isEmpty()) return "No notes matched \"$query\"."
        return notes.take(10).joinToString(separator = "\n") { n ->
            "- ${n.title}: ${n.content.take(200)}"
        }
    }

    private suspend fun rememberFact(key: String, value: String): String {
        AppDatabase.get(context).memoryDao().upsert(
            MemoryItem(key = key.trim(), value = value, updatedAt = System.currentTimeMillis())
        )
        return "Remembered: $key = $value."
    }

    private suspend fun recallFacts(): String {
        val dao = AppDatabase.get(context).memoryDao()
        val items: List<MemoryItem> = try {
            dao.allOnce()
        } catch (e: Exception) {
            try {
                dao.getAll().first()
            } catch (e2: Exception) {
                return "ERROR: could not read memory: ${e2.message ?: "database error"}"
            }
        }
        if (items.isEmpty()) return "No facts are saved in memory yet."
        return items.joinToString(separator = "\n") { "- ${it.key}: ${it.value}" }
    }

    // ------------------------------------------------------------------
    // Trains
    // ------------------------------------------------------------------

    private fun trainStatus(train: String): String {
        val t = train.trim()
        if (t.isBlank()) return "ERROR: no train number/name given."
        val template = settings.trainApiUrlTemplate.trim()
        if (template.isBlank()) {
            val ntesUrl = "https://enquiry.indianrail.gov.in/mntes/q?opt=TrainRunning&trainNo=" + Uri.encode(t)
            openUrl(ntesUrl)
            return "Live automatic train fetch is not configured yet: no train API URL template is set in Darling Settings. " +
                "The official NTES (Indian Railways) train-running page for '$t' has been opened in the browser instead, " +
                "where the current position, expected arrival/departure and platform (where NTES publishes it) can be seen. " +
                "Tell the user this honestly — do not invent a live position or platform."
        }
        val url = template.replace("{train}", URLEncoder.encode(t, "UTF-8"))
        val builder = Request.Builder().url(url).get()
        if (settings.rapidApiKey.isNotBlank()) {
            builder.header("X-RapidAPI-Key", settings.rapidApiKey.trim())
        }
        return try {
            http.newCall(builder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    "ERROR: train data source returned HTTP ${response.code}: ${body.take(500)}"
                } else {
                    body.take(3500)
                }
            }
        } catch (e: Exception) {
            "ERROR: could not fetch train status: ${e.message ?: "network error"}"
        }
    }

    // ------------------------------------------------------------------
    // Phone calls (Telecom)
    // ------------------------------------------------------------------

    @SuppressLint("MissingPermission")
    private fun answerCall(): String {
        if (Build.VERSION.SDK_INT < 26) {
            return "ERROR: answering a call programmatically needs Android 8 (API 26) or above."
        }
        if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
            return "ERROR: answer-calls permission (ANSWER_PHONE_CALLS) is not granted. Ask the user to allow the Phone permission for Darling."
        }
        val telecom = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return try {
            @Suppress("DEPRECATION") telecom.acceptRingingCall()
            "Ringing call answered. NOTE: Android does not let apps inject voice into a normal phone call — " +
                "the call is on the phone's normal audio path (put it on speaker for a speakerphone-style conversation)."
        } catch (e: SecurityException) {
            "ERROR: Android blocked answering the call: ${e.message ?: "security exception"}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun rejectCall(): String {
        if (Build.VERSION.SDK_INT < 28) {
            return "ERROR: ending a call programmatically needs Android 9 (API 28) or above."
        }
        if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
            return "ERROR: answer-calls permission (ANSWER_PHONE_CALLS) is not granted. Ask the user to allow the Phone permission for Darling."
        }
        val telecom = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        return try {
            val ended = telecom.endCall()
            if (ended) "Call rejected/ended." else "No active call was found to end."
        } catch (e: SecurityException) {
            "ERROR: Android blocked ending the call: ${e.message ?: "security exception"}"
        }
    }

    // ------------------------------------------------------------------
    // Info
    // ------------------------------------------------------------------

    private fun getDateTime(): String {
        val fmt = SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.getDefault())
        return "It is ${fmt.format(Date())} on this phone."
    }

    private fun getBattery(): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val capacity = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (capacity in 0..100) return "Battery is at $capacity%."
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) {
            "Battery is at ${(level * 100) / scale}%."
        } else "ERROR: battery level could not be read."
    }

    // ------------------------------------------------------------------
    // Macros (taught routines)
    // ------------------------------------------------------------------

    private fun saveMacro(name: String, stepsJson: String): String {
        val error = macroStore.save(name, stepsJson)
        return if (error == null) {
            val count = macroStore.get(name)?.steps?.size ?: 0
            "Macro saved: \"$name\" with $count steps. Boss can replay it any time with play_macro."
        } else "ERROR: could not save macro: $error"
    }

    private fun listMacros(): String {
        val macros = macroStore.list()
        if (macros.isEmpty()) return "No macros saved yet. Teach one with save_macro."
        return macros.joinToString(separator = "\n") { m ->
            val stepsText = m.steps.joinToString(separator = " -> ") { s ->
                when (s.verb) {
                    "wait" -> "wait ${s.seconds}s"
                    "go_back", "go_home" -> s.verb
                    else -> "${s.verb} \"${s.text}\""
                }
            }
            "- ${m.name}: $stepsText"
        }
    }

    private fun deleteMacro(name: String): String {
        return if (macroStore.delete(name)) "Macro deleted: \"$name\"."
        else "ERROR: no macro named \"$name\" was found."
    }

    /**
     * Replays a macro step by step. open_app reuses [openApp]; screen steps
     * go through [AccessibilityBridge]; waits use coroutine delay. Runs in
     * the caller's (background) coroutine, exactly like whatsappSend.
     */
    private suspend fun playMacro(name: String): String {
        val macro = macroStore.get(name)
            ?: return "ERROR: no macro named \"$name\" was found. Use list_macros to see saved macros."
        val log = StringBuilder()
        var failed = 0
        for ((index, step) in macro.steps.withIndex()) {
            val stepNo = index + 1
            try {
                when (step.verb) {
                    "open_app" -> {
                        val result = openApp(step.text)
                        log.append("Step $stepNo open_app \"${step.text}\": $result\n")
                        if (result.startsWith("ERROR")) failed++
                        delay(1500)
                    }
                    "tap_text" -> {
                        if (!AccessibilityBridge.isEnabled()) {
                            log.append("Step $stepNo tap_text: accessibility is off, skipped.\n")
                            failed++
                        } else if (AccessibilityBridge.tapByText(step.text)) {
                            log.append("Step $stepNo tap_text \"${step.text}\": tapped.\n")
                        } else {
                            log.append("Step $stepNo tap_text \"${step.text}\": not found on screen.\n")
                            failed++
                        }
                        delay(700)
                    }
                    "type_text" -> {
                        if (!AccessibilityBridge.isEnabled()) {
                            log.append("Step $stepNo type_text: accessibility is off, skipped.\n")
                            failed++
                        } else if (AccessibilityBridge.typeText(step.text)) {
                            log.append("Step $stepNo type_text: typed.\n")
                        } else {
                            log.append("Step $stepNo type_text: no focused field found.\n")
                            failed++
                        }
                        delay(500)
                    }
                    "go_back" -> {
                        val ok = AccessibilityBridge.isEnabled() && AccessibilityBridge.pressKey("back")
                        log.append("Step $stepNo go_back: ${if (ok) "done" else "failed (accessibility off?)"}.\n")
                        if (!ok) failed++
                        delay(500)
                    }
                    "go_home" -> {
                        val ok = AccessibilityBridge.isEnabled() && AccessibilityBridge.pressKey("home")
                        log.append("Step $stepNo go_home: ${if (ok) "done" else "failed (accessibility off?)"}.\n")
                        if (!ok) failed++
                        delay(500)
                    }
                    "wait" -> {
                        delay(step.seconds.coerceIn(0, 120) * 1000L)
                        log.append("Step $stepNo wait: ${step.seconds}s.\n")
                    }
                    else -> {
                        log.append("Step $stepNo: unknown verb '${step.verb}', skipped.\n")
                        failed++
                    }
                }
            } catch (e: Exception) {
                log.append("Step $stepNo ${step.verb}: failed — ${e.message ?: "error"}.\n")
                failed++
            }
        }
        val summary = if (failed == 0) {
            "Macro \"${macro.name}\" finished: all ${macro.steps.size} steps done."
        } else {
            "Macro \"${macro.name}\" finished with $failed of ${macro.steps.size} steps not completed — see the step log."
        }
        return summary + "\n" + log.toString().trim()
    }

    // ------------------------------------------------------------------
    // SOS
    // ------------------------------------------------------------------

    /** Last known location from the system providers, or null. */
    private fun lastKnownLocation(): Location? {
        val hasFine = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        val hasCoarse = hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (!hasFine && !hasCoarse) return null
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return null
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        var best: Location? = null
        for (provider in providers) {
            try {
                val loc = lm.getLastKnownLocation(provider) ?: continue
                val currentBest = best
                if (currentBest == null || loc.time > currentBest.time) best = loc
            } catch (e: SecurityException) {
                // Permission raced away; try the next provider.
            } catch (e: Exception) {
                // Provider missing on this device; try the next one.
            }
        }
        return best
    }

    private fun getLocationText(): String {
        val loc = lastKnownLocation()
            ?: return "ERROR: location unavailable. Either location permission " +
                "(ACCESS_FINE_LOCATION) is not granted for Darling, or the phone " +
                "has no recent location fix. Ask the user to grant the Location " +
                "permission and turn location on."
        return "Location: ${loc.latitude}, ${loc.longitude} " +
            "(https://maps.google.com/?q=${loc.latitude},${loc.longitude})"
    }

    /**
     * SOS, step by step, har step apna try/catch ke saath taaki ek fail
     * hone par baaki steps phir bhi chalein:
     * 1) location, 2) SMS to the emergency contact, 3) torch blink
     * (background thread, ~10 seconds), 4) call the emergency contact.
     */
    private fun triggerSos(): String {
        val steps = StringBuilder()
        steps.append("SOS TRIGGERED.\n")

        // 1) Location (kabhi fail ho to baaki steps phir bhi chalte hain).
        val locationText = try {
            val loc = lastKnownLocation()
            if (loc != null) {
                "https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
            } else "location unavailable"
        } catch (e: Exception) {
            "location unavailable"
        }
        steps.append("Location: $locationText\n")

        val contact = settings.emergencyContact.trim()
        if (contact.isBlank()) {
            steps.append(
                "SMS/call: SKIPPED — no emergency contact is saved. Ask the user " +
                    "to add one in Settings > Emergency contact number.\n"
            )
        } else {
            // 2) SMS (reuses the same SmsManager path as send_sms, but SOS
            // never waits for a confirmation — that is the whole point).
            try {
                if (!hasPermission(Manifest.permission.SEND_SMS)) {
                    steps.append("SMS: FAILED — SMS permission is not granted for Darling.\n")
                } else {
                    val sms: SmsManager? = if (Build.VERSION.SDK_INT >= 31) {
                        context.getSystemService(SmsManager::class.java)
                    } else {
                        @Suppress("DEPRECATION") SmsManager.getDefault()
                    }
                    if (sms == null) {
                        steps.append("SMS: FAILED — SMS service is not available on this phone.\n")
                    } else {
                        val message = "SOS! I need help. My location: $locationText — sent by Darling assistant."
                        val parts = sms.divideMessage(message)
                        if (parts.size > 1) {
                            sms.sendMultipartTextMessage(contact, null, parts, null, null)
                        } else {
                            sms.sendTextMessage(contact, null, message, null, null)
                        }
                        steps.append("SMS: sent to emergency contact $contact.\n")
                    }
                }
            } catch (e: Exception) {
                steps.append("SMS: FAILED — ${e.message ?: "error"}.\n")
            }

            // 3) Torch blink on a background thread (~10 seconds).
            try {
                startSosBlink()
                steps.append("Torch: blinking for about 10 seconds (cancel_sos stops it).\n")
            } catch (e: Exception) {
                steps.append("Torch: FAILED — ${e.message ?: "error"}.\n")
            }

            // 4) Call the emergency contact.
            try {
                val callResult = placeCall(contact)
                steps.append("Call: $callResult\n")
            } catch (e: Exception) {
                steps.append("Call: FAILED — ${e.message ?: "error"}.\n")
            }
        }

        if (contact.isBlank()) {
            // No contact saved: the torch blink still runs, so someone
            // nearby can notice. (Location was already reported above.)
            try {
                startSosBlink()
                steps.append("Torch: blinking for about 10 seconds (cancel_sos stops it).\n")
            } catch (e: Exception) {
                steps.append("Torch: FAILED — ${e.message ?: "error"}.\n")
            }
        }

        return steps.toString().trim()
    }

    private fun startSosBlink() {
        if (sosBlinkActive) return
        sosBlinkActive = true
        Thread {
            val deadline = System.currentTimeMillis() + 10_000L
            var on = false
            while (sosBlinkActive && System.currentTimeMillis() < deadline) {
                on = !on
                try {
                    toggleFlashlight(on)
                } catch (e: Exception) {
                    break
                }
                try {
                    Thread.sleep(450)
                } catch (e: InterruptedException) {
                    break
                }
            }
            sosBlinkActive = false
            try {
                toggleFlashlight(false)
            } catch (e: Exception) {
                // Torch already off / unavailable.
            }
        }.apply { isDaemon = true; start() }
    }

    private fun cancelSos(): String {
        val wasActive = sosBlinkActive
        sosBlinkActive = false
        try {
            toggleFlashlight(false)
        } catch (e: Exception) {
            // Ignore — cancelling must never fail loudly.
        }
        return if (wasActive) {
            "SOS torch blink stopped and the torch is off. (An SOS SMS or call that already went out cannot be unsent.)"
        } else {
            "No SOS blink was active. The torch is off."
        }
    }

    // ------------------------------------------------------------------
    // Mood
    // ------------------------------------------------------------------

    private fun setMood(mood: String): String {
        val clean = mood.trim().lowercase()
        val valid = listOf("happy", "flirty", "caring", "angry_pout", "sad", "serious")
        if (clean !in valid) {
            return "ERROR: unknown mood '$mood'. Valid moods: ${valid.joinToString(", ")}."
        }
        settings.currentMood = clean
        return "Mood set to $clean. It applies from the next reply/session — " +
            "Darling's voice and words will follow this mood until it is changed."
    }

    // ------------------------------------------------------------------
    // Clipboard & web search
    // ------------------------------------------------------------------

    private fun clipboard(): ClipboardManager? =
        context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    private fun readClipboard(): String {
        val cm = clipboard() ?: return "ERROR: clipboard service is not available."
        val clip = cm.primaryClip
        if (clip == null || clip.itemCount == 0) return "Clipboard is empty."
        val text = clip.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
        return if (text.isBlank()) "Clipboard has no readable text."
        else "Clipboard: ${text.take(1500)}"
    }

    private fun setClipboard(text: String): String {
        val cm = clipboard() ?: return "ERROR: clipboard service is not available."
        cm.setPrimaryClip(ClipData.newPlainText("Darling", text))
        return "Copied to clipboard: \"${text.take(120)}\""
    }

    /**
     * Very small web search over DuckDuckGo's HTML endpoint, parsed with a
     * light regex (same spirit as the train-status HTTP call above — no
     * new dependencies). Returns the top titles + links as plain text.
     */
    private fun searchWeb(query: String): String {
        val q = query.trim()
        if (q.isBlank()) return "ERROR: no search query given."
        val url = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8")
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) DarlingAssistant")
            .get()
            .build()
        return try {
            http.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return "ERROR: web search returned HTTP ${response.code}."
                }
                val linkRegex = Regex(
                    "<a[^>]+class=\"result__a\"[^>]+href=\"([^\"]+)\"[^>]*>(.*?)</a>",
                    RegexOption.DOT_MATCHES_ALL
                )
                val tagRegex = Regex("<[^>]+>")
                val results = linkRegex.findAll(body).take(5).mapIndexed { i, m ->
                    val rawHref = m.groupValues[1]
                    val title = tagRegex.replace(m.groupValues[2], "").trim()
                    // DuckDuckGo wraps results in a redirect: ...&uddg=<real url>
                    val uddg = Regex("[?&]uddg=([^&]+)").find(rawHref)?.groupValues?.get(1)
                    val link = if (uddg != null) {
                        try {
                            java.net.URLDecoder.decode(uddg, "UTF-8")
                        } catch (e: Exception) {
                            rawHref
                        }
                    } else rawHref
                    "${i + 1}. $title — $link"
                }.toList()
                if (results.isEmpty()) {
                    "No web results could be read for \"$q\" (the search page layout may have changed)."
                } else {
                    "Web results for \"$q\":\n" + results.joinToString("\n")
                }
            }
        } catch (e: Exception) {
            "ERROR: web search failed: ${e.message ?: "network error"}"
        }
    }
}
