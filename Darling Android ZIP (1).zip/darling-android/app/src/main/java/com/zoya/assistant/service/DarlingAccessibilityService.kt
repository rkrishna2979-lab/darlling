package com.zoya.assistant.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Accessibility service backing [AccessibilityBridge].
 *
 * Provides screen reading (all visible text / content descriptions) and
 * simple interactions: tap by text, type into the focused/editable field,
 * scroll forward, global back/home/recents keys and a WhatsApp-style
 * "Send" button tap. All operations work on the current active window only
 * and fail soft (false / empty string) when there is no window.
 */
class DarlingAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityBridge.service = this
    }

    override fun onDestroy() {
        if (AccessibilityBridge.service === this) {
            AccessibilityBridge.service = null
        }
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Reading/interaction is on demand via AccessibilityBridge; no
        // continuous event processing is needed.
    }

    override fun onInterrupt() {
        // Nothing to interrupt; interactions are one-shot.
    }

    // ------------------------------------------------------------------
    // Screen reading
    // ------------------------------------------------------------------

    fun readScreenText(): String {
        val root = rootInActiveWindow ?: return ""
        val texts = ArrayList<String>()
        try {
            collectTexts(root, texts)
        } catch (e: Exception) {
            // Window changed mid-traversal; return whatever was collected.
        } finally {
            try {
                root.recycle()
            } catch (e: Exception) {
                // Already recycled by the system; ignore.
            }
        }
        return texts.joinToString(" | ").take(2000)
    }

    private fun collectTexts(node: AccessibilityNodeInfo, out: MutableList<String>) {
        node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        for (i in 0 until node.childCount) {
            val child = try {
                node.getChild(i)
            } catch (e: Exception) {
                null
            } ?: continue
            try {
                collectTexts(child, out)
            } finally {
                try {
                    child.recycle()
                } catch (e: Exception) {
                    // Ignore; node may already be invalid.
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Node search helpers
    // ------------------------------------------------------------------

    /**
     * Depth-first search starting at (and including) [node]. Returns the
     * first node matching [predicate]; unmatched child nodes are recycled.
     * The returned node is owned by the caller.
     */
    private fun findNode(
        node: AccessibilityNodeInfo,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = try {
                node.getChild(i)
            } catch (e: Exception) {
                null
            } ?: continue
            val found = findNode(child, predicate)
            if (found != null) return found
            try {
                child.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
        }
        return null
    }

    private fun findNodeByText(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val needle = text.trim().lowercase()
        if (needle.isEmpty()) {
            try {
                root.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
            return null
        }
        val found = findNode(root) { node ->
            val nodeText = node.text?.toString()?.trim()?.lowercase()
            val nodeDesc = node.contentDescription?.toString()?.trim()?.lowercase()
            nodeText == needle || nodeDesc == needle ||
                (nodeText?.contains(needle) == true) ||
                (nodeDesc?.contains(needle) == true)
        }
        if (found == null || found === root) {
            // Caller owns the found node; recycle the root only when it is
            // not the node being returned.
            if (found == null) {
                try {
                    root.recycle()
                } catch (e: Exception) {
                    // Ignore.
                }
            }
        }
        return found
    }

    /** Walks up from [node] to the first clickable ancestor and clicks it. */
    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var clicked = false
        while (current != null) {
            if (current.isClickable) {
                clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                break
            }
            current = try {
                current.parent
            } catch (e: Exception) {
                null
            }
        }
        return clicked
    }

    // ------------------------------------------------------------------
    // Actions used by AccessibilityBridge
    // ------------------------------------------------------------------

    fun tapByText(text: String): Boolean {
        val node = findNodeByText(text) ?: return false
        val clicked = clickNodeOrParent(node)
        try {
            node.recycle()
        } catch (e: Exception) {
            // Ignore.
        }
        return clicked
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = null
        try {
            target = try {
                root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            } catch (e: Exception) {
                null
            }
            if (target == null) {
                target = findNode(root) { node ->
                    node.isEditable ||
                        (node.className?.toString()?.contains("EditText") == true)
                }
            }
            val node = target ?: return false
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    text
                )
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } finally {
            try {
                target?.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
            try {
                root.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
        }
    }

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = null
        try {
            target = findNode(root) { it.isScrollable }
            val node = target ?: return false
            return node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        } finally {
            try {
                target?.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
            try {
                root.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
        }
    }

    fun tapSendButton(): Boolean {
        val root = rootInActiveWindow ?: return false
        var target: AccessibilityNodeInfo? = null
        try {
            // Prefer a directly clickable node whose description/text says
            // "Send" (WhatsApp's send button is found by description).
            target = findNode(root) { node ->
                node.isClickable &&
                    (node.contentDescription?.toString()
                        ?.contains("send", ignoreCase = true) == true ||
                        node.text?.toString()?.trim()
                            ?.equals("send", ignoreCase = true) == true)
            }
            if (target == null) {
                target = findNode(root) { node ->
                    node.contentDescription?.toString()
                        ?.contains("send", ignoreCase = true) == true ||
                        node.text?.toString()?.trim()
                            ?.equals("send", ignoreCase = true) == true ||
                        node.text?.toString()?.trim()
                            ?.contains("send", ignoreCase = true) == true
                }
            }
            val node = target ?: return false
            return clickNodeOrParent(node)
        } finally {
            try {
                target?.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
            try {
                root.recycle()
            } catch (e: Exception) {
                // Ignore.
            }
        }
    }

    fun pressKey(key: String): Boolean {
        val action = when (key.trim().lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents", "recent", "overview" -> GLOBAL_ACTION_RECENTS
            else -> return false
        }
        return performGlobalAction(action)
    }
}
