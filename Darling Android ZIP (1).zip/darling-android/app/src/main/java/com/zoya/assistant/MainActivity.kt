package com.zoya.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.zoya.assistant.service.WakeWordService
import com.zoya.assistant.ui.AppViewModel
import com.zoya.assistant.ui.screens.ChatScreen
import com.zoya.assistant.ui.screens.VoiceScreen
import com.zoya.assistant.ui.screens.NotesScreen
import com.zoya.assistant.ui.screens.SettingsScreen
import com.zoya.assistant.ui.screens.SetupScreen
import com.zoya.assistant.ui.theme.DarlingTheme

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (vm.settings.wakeWordEnabled) {
            try {
                WakeWordService.start(this)
            } catch (e: Exception) {
                // foreground service start can fail in background; user can enable from Setup screen
            }
        }
        val openCalling = intent?.getStringExtra("darling_action") == "OPEN_CALLING"

        setContent {
            DarlingTheme {
                var tab by remember { mutableStateOf(0) }
                LaunchedEffect(Unit) {
                    if (openCalling) vm.startLive()
                }
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = tab == 0,
                                onClick = { tab = 0 },
                                icon = { Text("◉") },
                                label = { Text("Darling") }
                            )
                            NavigationBarItem(
                                selected = tab == 1,
                                onClick = { tab = 1 },
                                icon = { Text("💬") },
                                label = { Text("Chat") }
                            )
                            NavigationBarItem(
                                selected = tab == 2,
                                onClick = { tab = 2 },
                                icon = { Text("📝") },
                                label = { Text("Notes") }
                            )
                            NavigationBarItem(
                                selected = tab == 3,
                                onClick = { tab = 3 },
                                icon = { Text("🛠") },
                                label = { Text("Setup") }
                            )
                            NavigationBarItem(
                                selected = tab == 4,
                                onClick = { tab = 4 },
                                icon = { Text("⚙") },
                                label = { Text("Settings") }
                            )
                        }
                    }
                ) { inner ->
                    androidx.compose.foundation.layout.Box(Modifier.padding(inner)) {
                        when (tab) {
                            0 -> VoiceScreen(vm)
                            1 -> ChatScreen(vm)
                            2 -> NotesScreen(vm)
                            3 -> SetupScreen(vm)
                            else -> SettingsScreen(vm)
                        }
                    }
                }
            }
        }
    }
}
