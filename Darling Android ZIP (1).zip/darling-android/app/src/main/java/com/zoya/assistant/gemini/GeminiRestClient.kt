package com.zoya.assistant.gemini

import com.zoya.assistant.core.AppConfig
import com.zoya.assistant.core.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** A single chat turn for the REST API. [role] is "user" or "model". */
data class ChatMsg(val role: String, val text: String)

/**
 * Gemini text/tool brain over the REST generateContent API.
 *
 * - Text answers, plus a function-calling loop (up to 5 rounds) when a
 *   [ToolRegistry] is supplied.
 * - The API key is only ever placed in the request URL; it is never logged.
 */
class GeminiRestClient(
    private val settings: SettingsStore,
    private val tools: ToolRegistry? = null
) {

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    /** A function call extracted from one model turn. */
    private data class PendingCall(val name: String, val args: JSONObject)

    /** Quick check used by the Settings "Test API Key" button. */
    suspend fun testKey(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val key = settings.apiKey.trim()
        if (key.isBlank()) {
            return@withContext false to "API key is not set. Add your Gemini API key in Settings first."
        }
        val url = AppConfig.REST_BASE + "v1beta/models?key=" + URLEncoder.encode(key, "UTF-8")
        val request = Request.Builder().url(url).get().build()
        try {
            http.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (response.code == 200) {
                    true to "API key works. Gemini models are reachable."
                } else {
                    false to "API key test failed (HTTP ${response.code}): ${body.take(300)}"
                }
            }
        } catch (e: Exception) {
            false to "API key test failed: ${e.message ?: "network error"}"
        }
    }

    /**
     * Sends [history] to the chat model and returns the model's text answer.
     * If the model requests tools, they are executed and the results are fed
     * back (role "function" with functionResponse parts, as the Gemini
     * generateContent API requires) until a text answer arrives or 5 tool
     * rounds are exhausted.
     */
    suspend fun send(history: List<ChatMsg>): String = withContext(Dispatchers.IO) {
        val key = settings.apiKey.trim()
        if (key.isBlank()) {
            throw IllegalStateException("Gemini API key is not set. Add it in Settings first.")
        }

        // Mutable conversation: user/model turns plus any tool turns we add.
        val contents = JSONArray()
        for (msg in history) {
            val role = if (msg.role == "model") "model" else "user"
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            )
        }

        val url = AppConfig.REST_BASE +
            "v1beta/models/" + settings.chatModel.trim() +
            ":generateContent?key=" + URLEncoder.encode(key, "UTF-8")

        for (round in 0 until 5) {
            val bodyJson = JSONObject()
                .put("contents", contents)
                .put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", settings.systemInstruction()))
                    )
                )
            if (tools != null) {
                bodyJson.put(
                    "tools",
                    JSONArray().put(
                        JSONObject().put("functionDeclarations", tools.functionDeclarations())
                    )
                )
            }

            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toString().toRequestBody(jsonMedia))
                .header("Content-Type", "application/json")
                .build()

            val responseJson: JSONObject = http.newCall(request).execute().use { response ->
                val bodyText = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    throw IllegalStateException(
                        "Gemini API error (HTTP ${response.code}): ${bodyText.take(800)}"
                    )
                }
                if (bodyText.isBlank()) {
                    throw IllegalStateException("Gemini API returned an empty response.")
                }
                JSONObject(bodyText)
            }

            val candidates = responseJson.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
                ?: throw IllegalStateException("Gemini API returned no candidates: ${responseJson.toString().take(400)}")
            val content = firstCandidate.optJSONObject("content")
                ?: throw IllegalStateException("Gemini API returned no content.")
            val parts = content.optJSONArray("parts") ?: JSONArray()

            // Collect text parts and function calls from this turn.
            val textBuilder = StringBuilder()
            val calls = mutableListOf<PendingCall>()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.has("text")) {
                    textBuilder.append(part.optString("text"))
                }
                val fc = part.optJSONObject("functionCall")
                if (fc != null) {
                    val name = fc.optString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    if (name.isNotBlank()) calls.add(PendingCall(name, args))
                }
            }

            if (calls.isEmpty()) {
                return@withContext textBuilder.toString()
            }

            // The model asked for tools: record its turn, run the tools, then
            // feed every result back as one role="function" content.
            contents.put(content)
            val functionParts = JSONArray()
            for (call in calls) {
                val result: String = if (tools == null) {
                    "ERROR: tools are not available in this session."
                } else {
                    try {
                        tools.execute(call.name, call.args)
                    } catch (e: Exception) {
                        "ERROR: tool ${call.name} failed: ${e.message ?: "unknown error"}"
                    }
                }
                functionParts.put(
                    JSONObject().put(
                        "functionResponse",
                        JSONObject()
                            .put("name", call.name)
                            .put("response", JSONObject().put("result", result))
                    )
                )
            }
            contents.put(JSONObject().put("role", "function").put("parts", functionParts))
            // Next round: the model sees the tool results and answers (or
            // requests more tools).
        }

        throw IllegalStateException("The model kept requesting tools after 5 rounds; stopped to avoid a loop.")
    }
}
