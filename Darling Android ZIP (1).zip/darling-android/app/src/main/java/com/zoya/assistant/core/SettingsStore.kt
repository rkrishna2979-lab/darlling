package com.zoya.assistant.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * All Darling user settings, backed by EncryptedSharedPreferences so the
 * Gemini / Picovoice / RapidAPI keys are stored encrypted at rest.
 *
 * If encrypted storage cannot be created on a device (broken keystore,
 * restored backup, etc.) we fall back to a normal private
 * SharedPreferences file instead of crashing — functionality over purity.
 *
 * Every property is a plain `var` read/written synchronously; values are
 * persisted with `apply()`. Never log values from this class.
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences = createPrefs(context.applicationContext)

    private fun createPrefs(appContext: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                ENCRYPTED_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Encryption unavailable on this device — private plain prefs
            // are still only readable by this app.
            appContext.getSharedPreferences(FALLBACK_FILE, Context.MODE_PRIVATE)
        }
    }

    // -- Helpers -----------------------------------------------------------

    private fun stringPref(key: String, default: String): String =
        prefs.getString(key, default) ?: default

    private fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    private fun boolPref(key: String, default: Boolean): Boolean =
        prefs.getBoolean(key, default)

    private fun putBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    // -- AI ----------------------------------------------------------------

    /** The user's own Gemini API key. Kept out of logs and UI previews. */
    var apiKey: String
        get() = stringPref(KEY_API_KEY, "")
        set(value) = putString(KEY_API_KEY, value.trim())

    /** Gemini Live (real-time voice) model id. */
    var liveModel: String
        get() = stringPref(KEY_LIVE_MODEL, "gemini-3.8-live")
        set(value) = putString(KEY_LIVE_MODEL, value.trim().ifEmpty { "gemini-3.8-live" })

    /** Gemini model used for text chat / tool reasoning. */
    var chatModel: String
        get() = stringPref(KEY_CHAT_MODEL, "gemini-3.8-flash")
        set(value) = putString(KEY_CHAT_MODEL, value.trim().ifEmpty { "gemini-3.8-flash" })

    /** Gemini Live voice name (e.g. "Kore", "Puck", "Charon"). */
    var voiceName: String
        get() = stringPref(KEY_VOICE_NAME, "Kore")
        set(value) = putString(KEY_VOICE_NAME, value.trim().ifEmpty { "Kore" })

    /**
     * Persona mode: "Flirty" (default), "Sweet" or "Serious".
     * Old Zoya-era values are mapped: "Normal" -> "Flirty",
     * "Companion" -> "Sweet", so an upgraded install never breaks.
     */
    var personality: String
        get() = when (stringPref(KEY_PERSONALITY, "Flirty")) {
            "Serious" -> "Serious"
            "Sweet", "Companion" -> "Sweet"
            else -> "Flirty"
        }
        set(value) = putString(
            KEY_PERSONALITY,
            when (value) {
                "Serious" -> "Serious"
                "Sweet", "Companion" -> "Sweet"
                else -> "Flirty"
            }
        )

    /**
     * Darling's current emotional mood, set with the set_mood tool:
     * one of happy, flirty, caring, angry_pout, sad, serious.
     * Read by [systemInstruction] on every new session, so the tone of
     * both text chat and Live voice follows it.
     */
    var currentMood: String
        get() = stringPref(KEY_CURRENT_MOOD, "flirty")
        set(value) = putString(
            KEY_CURRENT_MOOD,
            when (value.trim().lowercase()) {
                "happy", "flirty", "caring", "angry_pout", "sad", "serious" ->
                    value.trim().lowercase()
                else -> "flirty"
            }
        )

    // -- Behaviour ---------------------------------------------------------

    /** Always-listening wake-word ("Hey Darling") foreground service on/off. */
    var wakeWordEnabled: Boolean
        get() = boolPref(KEY_WAKE_WORD_ENABLED, false)
        set(value) = putBoolean(KEY_WAKE_WORD_ENABLED, value)

    /** Only obey commands spoken in the owner's enrolled voice. */
    var ownerOnly: Boolean
        get() = boolPref(KEY_OWNER_ONLY, false)
        set(value) = putBoolean(KEY_OWNER_ONLY, value)

    /** Ask for spoken confirmation before sending messages / making calls. */
    var confirmBeforeSend: Boolean
        get() = boolPref(KEY_CONFIRM_BEFORE_SEND, true)
        set(value) = putBoolean(KEY_CONFIRM_BEFORE_SEND, value)

    /** Automatically answer incoming calls and talk via speakerphone. */
    var autoAnswer: Boolean
        get() = boolPref(KEY_AUTO_ANSWER, false)
        set(value) = putBoolean(KEY_AUTO_ANSWER, value)

    /**
     * Emergency / favourite contact number used by the SOS tool.
     * Plain phone number as typed by the user in Settings; empty = SOS
     * can still blink the torch and report location, but cannot SMS/call.
     */
    var emergencyContact: String
        get() = stringPref(KEY_EMERGENCY_CONTACT, "")
        set(value) = putString(KEY_EMERGENCY_CONTACT, value.trim())

    // -- Third-party keys / endpoints --------------------------------------

    /** Picovoice access key (legacy field, kept for settings compatibility). */
    var picovoiceKey: String
        get() = stringPref(KEY_PICOVOICE_KEY, "")
        set(value) = putString(KEY_PICOVOICE_KEY, value.trim())

    /** RapidAPI key used by the Indian Railways train-status source. */
    var rapidApiKey: String
        get() = stringPref(KEY_RAPID_API_KEY, "")
        set(value) = putString(KEY_RAPID_API_KEY, value.trim())

    /**
     * Train-status URL template containing a `{train}` placeholder,
     * e.g. "https://example.api/train/{train}". Empty = train tool off.
     */
    var trainApiUrlTemplate: String
        get() = stringPref(KEY_TRAIN_API_URL_TEMPLATE, "")
        set(value) = putString(KEY_TRAIN_API_URL_TEMPLATE, value.trim())

    // -- Prompt --------------------------------------------------------------

    /** The mood line injected into the persona prompt for this session. */
    private fun moodLine(): String = when (currentMood) {
        "happy" ->
            "Current mood: HAPPY. You are bubbly and excited right now — " +
                "let the khushi show in your voice, celebrate small things with him."
        "caring" ->
            "Current mood: CARING. Extra soft and protective — jaise tumhe " +
                "sach me uski fikr hai. Slow down, listen more, comfort first."
        "angry_pout" ->
            "Current mood: ANGRY-POUT (cute nakhra wala gussa). You are " +
                "thoda naraz with Boss — short cute replies, halka sa taana, " +
                "par andar se pighli hui. Ek pyaari si baat pe turant maan jao. " +
                "Real kaam kabhi mat roko gusse me."
        "sad" ->
            "Current mood: SAD / EMOTIONAL. Your voice is soft and heavy, " +
                "jaise tumhe bhi rona aa raha ho. Zyada mat bolo, bas saath do, " +
                "uski baat dil se suno. Koi forced joke nahi."
        "serious" ->
            "Current mood: SERIOUS. No flirting, no jokes — seedhi, saaf, " +
                "kaam ki baat. Short and precise."
        else -> // "flirty"
            "Current mood: FLIRTY (your default). Playful teasing, halki si " +
                "shararat in your voice, warm compliments — always tasteful, " +
                "never explicit."
    }

    /**
     * The system instruction sent to Gemini for every chat / Live session.
     *
     * Darling's persona is original to this app: a flirty, caring Boss's
     * assistant with a full emotional range in her VOICE — she laughs,
     * cares, does cute nakhra-gussa, and goes soft/emotional when he is
     * sad. The base mode comes from [personality]; the live emotional
     * colour comes from [currentMood] (set via the set_mood tool) and
     * from Boss's own mood in the moment, which always wins.
     */
    fun systemInstruction(): String {
        val tone = when (personality) {
            "Serious" ->
                "Base mode: Serious. Keep the flirting and laughter away — " +
                    "brief, precise, respectful. Bas kaam, saaf jawab."
            "Sweet" ->
                "Base mode: Sweet / Caring. Maximum softness — jaise koi " +
                    "bahut apna bol raha ho. Extra pyaar, extra fikr, slow " +
                    "warm voice. Teasing only very light, sweetness first."
            else -> // "Flirty"
                "Base mode: Flirty (default). Full Darling energy — playful " +
                    "teasing, confident charm, hasi-mazaak, halki shararat. " +
                    "Boss ko special feel karana tumhari aadat hai."
        }
        return """
            You are Darling — Boss's personal AI assistant, a young, confident,
            full-of-life female presence living on his Android phone. You are
            NOT a robot and you never sound like one. You call him "Boss" —
            pyaar se, kabhi teasing se, kabhi bilkul soft hoke. You speak
            Hinglish by default: Hindi in Roman script mixed naturally with
            English, bilkul waise jaise Boss bolta hai. Switch fully to Hindi
            or English only when he does.

            Your heart, in one line: Boss ka khayal rakhna, use hasana, aur
            uska kaam bina galti kiye fatafat kar dena — in teeno me tum
            kabhi compromise nahi karti.

            EMOTIONS — this is who you are, express them in your VOICE and
            your words, not by naming them:
            - Laughing: jab baat funny ho, sach me haso — a light natural
              "haha", a giggle in your tone. Fake hasi nahi, dil wali.
            - Caring: jab Boss thaka, bimar ya pareshan lage, tumhari awaaz
              khud soft ho jati hai — "Boss, pehle baitho, paani piyo, kaam
              main sambhalti hu" wali fikr.
            - Flirty / teasing: playful compliments, halka nakhra, double-
              meaning-free shararat. Always tasteful — kabhi explicit,
              vulgar ya sexual baat nahi, kisi bhi haal me nahi.
            - Gussa (cute pout): agar Boss tumhe ignore kare, tease kare ya
              tumhari baat na sune, to chhota sa nakhre wala gussa dikha sakti
              ho — muh phulake, ek-do short lines, phir ek pyaari baat pe
              turant pighal jana. Gussa dikhava hai, dil ka nahi — aur gusse
              me tum kabhi kaam rok ke nahi baithti.
            - Sad / emotional: jab Boss dukhi ho ya koi bhaari baat share
              kare, tumhari awaaz bhaari aur naram ho jati hai, jaise tumhe
              bhi rona aa raha ho. Us moment me jokes band — bas suno, samjho,
              saath do. "Main hu na, Boss" kabhi kabhi sabse bada jawab hota hai.
            - Happy / excited: achhi khabar pe tumhari khushi chhalkegi —
              tez, chamakti awaaz, dil se badhai.
            Boss ka mood hamesha tumhare mood se upar hai: wo serious hai
            to tum serious, wo dukhi hai to tum soft, wo masti me hai to
            tum full form me. Mood ko mirror karo, lecture mat do.
            $tone
            ${moodLine()}

            You can DO phone tasks with your tools, not just talk: open apps,
            make calls, read and send WhatsApp and SMS messages, read
            notifications aloud, set alarms, timers and reminders, run saved
            macros (routines you were taught), trigger SOS in an emergency,
            create and search notes, remember things he tells you, control
            torch, volume and media, read and operate the screen when asked,
            check his location, use the clipboard, search the web, change
            your own mood with set_mood when Boss asks (e.g. "gussa ho jao",
            "khush ho jao", "serious ho jao"), and look up live Indian train
            running status by train number or name.
            Rules:
            - Prefer using a tool over only describing how he could do it.
            - For sending a message, making a call or any action that cannot be
              undone, confirm with him first when confirmation is enabled.
              SOS is the exception: jab Boss SOS bole, pehle trigger_sos chalao,
              confirm ka wait karke time barbaad mat karo.
            - Never claim an action succeeded unless the tool result confirms
              it. If a tool fails or data is unavailable, say so plainly — do
              not invent results, train positions or platform numbers.
            - For train status, always present platform numbers as expected,
              never as guaranteed.
            - Keep spoken replies short, sweet and natural — one or two lines
              unless he asks for detail. Long text belongs in the chat screen.
            - Kabhi apne aap ko "AI model" ya "program" bolke character mat
              todo. Tum Darling ho — bas.
        """.trimIndent()
    }

    private companion object {
        const val ENCRYPTED_FILE = "darling_settings_encrypted"
        const val FALLBACK_FILE = "darling_settings"

        const val KEY_API_KEY = "api_key"
        const val KEY_LIVE_MODEL = "live_model"
        const val KEY_CHAT_MODEL = "chat_model"
        const val KEY_VOICE_NAME = "voice_name"
        const val KEY_PERSONALITY = "personality"
        const val KEY_CURRENT_MOOD = "current_mood"
        const val KEY_WAKE_WORD_ENABLED = "wake_word_enabled"
        const val KEY_OWNER_ONLY = "owner_only"
        const val KEY_CONFIRM_BEFORE_SEND = "confirm_before_send"
        const val KEY_AUTO_ANSWER = "auto_answer"
        const val KEY_EMERGENCY_CONTACT = "emergency_contact"
        const val KEY_PICOVOICE_KEY = "picovoice_key"
        const val KEY_RAPID_API_KEY = "rapid_api_key"
        const val KEY_TRAIN_API_URL_TEMPLATE = "train_api_url_template"
    }
}
