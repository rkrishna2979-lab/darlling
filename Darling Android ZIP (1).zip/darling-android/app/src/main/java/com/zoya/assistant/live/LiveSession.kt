package com.zoya.assistant.live

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import androidx.core.content.ContextCompat
import com.zoya.assistant.core.AppConfig
import com.zoya.assistant.core.SettingsStore
import com.zoya.assistant.gemini.ToolRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * Gemini Live voice session: LISTEN -> THINK -> SPEAK -> LISTEN, continuously.
 *
 * - WebSocket to the Gemini Live (BidiGenerateContent) API; setup carries the
 *   model, voice, system instruction and all [ToolRegistry] function
 *   declarations.
 * - Mic: AudioRecord, 16 kHz mono PCM16 (VOICE_COMMUNICATION source so the
 *   phone applies echo cancellation), streamed as realtimeInput audio.
 * - Speaker: AudioTrack, 24 kHz mono PCM16, fed from modelTurn inlineData.
 * - Barge-in: while the model is speaking, sustained loud mic input
 *   (RMS > 0.25 for 3 chunks) flushes the playback queue and drops back to
 *   LISTENING; the server also receives the new audio and interrupts itself.
 * - Tool calls from the model are executed with [ToolRegistry] and returned
 *   as toolResponse functionResponses.
 *
 * The API key is only used in the connection URL; it is never logged, and it
 * is stripped from any error text handed to the listener.
 */
class LiveSession(
    private val context: Context,
    private val settings: SettingsStore,
    private val tools: ToolRegistry,
    private val listener: Listener
) {

    interface Listener {
        fun onState(state: String)
        fun onLevel(level: Float)
        fun onUserTranscript(text: String)
        fun onModelTranscript(text: String)
        fun onError(message: String)
    }

    companion object {
        const val STATE_CONNECTING = "CONNECTING"
        const val STATE_LISTENING = "LISTENING"
        const val STATE_THINKING = "THINKING"
        const val STATE_SPEAKING = "SPEAKING"
        const val STATE_ERROR = "ERROR"
        const val STATE_STOPPED = "STOPPED"

        private const val INPUT_SAMPLE_RATE = 16000
        private const val OUTPUT_SAMPLE_RATE = 24000
        private const val CHUNK_BYTES = 3200 // ~100 ms of 16 kHz PCM16 mono
        private const val BARGE_RMS_THRESHOLD = 0.25f
        private const val BARGE_CHUNKS_NEEDED = 3
    }

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS) // Live sessions are long-lived
        // NO client pingInterval on purpose: the Gemini Live server sends its
        // own pings and OkHttp auto-pongs them. Client-initiated pings are
        // not answered by Google's gateway, and OkHttp then kills the socket
        // with "sent ping but didn't receive pong" ~20s into every session
        // (this was the v1.0 voice bug, confirmed on-device 2026-10-20).
        .build()

    private var scope: CoroutineScope = newScope()
    private fun newScope(): CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    @Volatile private var webSocket: WebSocket? = null
    @Volatile private var running: Boolean = false
    @Volatile private var stoppedByUser: Boolean = false
    @Volatile private var captureStarted: Boolean = false

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var captureThread: Thread? = null

    /** True while model audio is being (or has just been) written to the track. */
    @Volatile private var modelSpeaking: Boolean = false
    /** Ignore model audio arriving just after a local barge-in flush. */
    @Volatile private var suppressPlaybackUntilMs: Long = 0L
    private var loudChunkCount: Int = 0

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    fun start() {
        if (running) return
        if (settings.apiKey.isBlank()) {
            listener.onState(STATE_ERROR)
            listener.onError("Gemini API key is not set. Add it in Settings first.")
            return
        }
        stoppedByUser = false
        running = true
        captureStarted = false
        modelSpeaking = false
        loudChunkCount = 0
        if (scope.coroutineContext[kotlinx.coroutines.Job]?.isCancelled != false) {
            // Fresh scope if the previous one was cancelled by stop().
            try { scope = newScope() } catch (e: Exception) { /* keep old scope */ }
        }

        initPlayback()
        listener.onState(STATE_CONNECTING)

        val url = AppConfig.LIVE_WS_URL + "?key=" + URLEncoder.encode(settings.apiKey.trim(), "UTF-8")
        val request = Request.Builder().url(url).build()
        webSocket = http.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(webSocket: WebSocket, response: Response) {
                sendSetup()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (stoppedByUser) return
                running = false
                listener.onState(STATE_ERROR)
                listener.onError("Live connection failed: ${sanitize(t.message ?: "network error")}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (stoppedByUser) return
                running = false
                listener.onState(STATE_STOPPED)
                if (code != 1000) {
                    listener.onError("Live connection closed (code $code): ${sanitize(reason)}")
                }
            }
        })
    }

    fun stop() {
        stoppedByUser = true
        running = false
        captureStarted = false
        modelSpeaking = false
        stopCapture()
        releasePlayback()
        try { webSocket?.close(1000, "client stop") } catch (e: Exception) { /* ignore */ }
        webSocket = null
        try { scope.cancel() } catch (e: Exception) { /* ignore */ }
        scope = newScope()
        listener.onState(STATE_STOPPED)
    }

    /** User spoke over Darling (or tapped interrupt): drop queued speech now. */
    fun interrupt() {
        flushPlayback()
        modelSpeaking = false
        suppressPlaybackUntilMs = System.currentTimeMillis() + 500
        if (running) listener.onState(STATE_LISTENING)
    }

    /** Sends a typed message into the live conversation. */
    fun sendText(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return
        val msg = JSONObject()
            .put(
                "clientContent", JSONObject()
                    .put(
                        "turns", JSONArray().put(
                            JSONObject()
                                .put("role", "user")
                                .put("parts", JSONArray().put(JSONObject().put("text", trimmed)))
                        )
                    )
                    .put("turnComplete", true)
            )
        if (webSocket?.send(msg.toString()) == true) {
            listener.onState(STATE_THINKING)
        } else {
            listener.onError("Live session is not connected; cannot send text.")
        }
    }

    // ------------------------------------------------------------------
    // Setup
    // ------------------------------------------------------------------

    private fun sendSetup() {
        val setup = JSONObject()
            .put("model", "models/" + settings.liveModel.trim())
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject()
                            .put(
                                "voiceConfig", JSONObject()
                                    .put(
                                        "prebuiltVoiceConfig", JSONObject()
                                            .put("voiceName", settings.voiceName)
                                    )
                            )
                    )
            )
            .put(
                "systemInstruction", JSONObject()
                    .put("parts", JSONArray().put(JSONObject().put("text", settings.systemInstruction())))
            )
            .put(
                "tools", JSONArray().put(
                    JSONObject().put("functionDeclarations", tools.functionDeclarations())
                )
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())

        val sent = webSocket?.send(JSONObject().put("setup", setup).toString()) ?: false
        if (!sent) {
            listener.onState(STATE_ERROR)
            listener.onError("Could not send the Live setup message.")
        }
    }

    // ------------------------------------------------------------------
    // Server messages
    // ------------------------------------------------------------------

    private fun handleServerMessage(text: String) {
        val root = try {
            JSONObject(text)
        } catch (e: Exception) {
            return
        }

        if (root.has("setupComplete")) {
            listener.onState(STATE_LISTENING)
            startCapture()
            return
        }

        root.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted", false)) {
                flushPlayback()
                modelSpeaking = false
                listener.onState(STATE_LISTENING)
            }
            sc.optJSONObject("inputTranscription")?.optString("text")
                ?.takeIf { it.isNotBlank() }?.let { listener.onUserTranscript(it) }
            sc.optJSONObject("outputTranscription")?.optString("text")
                ?.takeIf { it.isNotBlank() }?.let { listener.onModelTranscript(it) }

            sc.optJSONObject("modelTurn")?.let { turn ->
                val parts = turn.optJSONArray("parts") ?: JSONArray()
                for (i in 0 until parts.length()) {
                    val part = parts.optJSONObject(i) ?: continue
                    val inline = part.optJSONObject("inlineData")
                    val data = inline?.optString("data").orEmpty()
                    if (data.isNotBlank()) {
                        playAudioChunk(data)
                    } else if (part.has("text")) {
                        val partText = part.optString("text")
                        if (partText.isNotBlank()) listener.onModelTranscript(partText)
                    }
                }
            }

            if (sc.optBoolean("turnComplete", false)) {
                modelSpeaking = false
                if (running) listener.onState(STATE_LISTENING)
            }
        }

        root.optJSONObject("toolCall")?.let { toolCall ->
            val calls = toolCall.optJSONArray("functionCalls") ?: JSONArray()
            if (calls.length() > 0) listener.onState(STATE_THINKING)
            for (i in 0 until calls.length()) {
                val fc = calls.optJSONObject(i) ?: continue
                val id = fc.optString("id", "")
                val name = fc.optString("name")
                val callArgs = fc.optJSONObject("args") ?: JSONObject()
                if (name.isBlank()) continue
                scope.launch {
                    val result = try {
                        tools.execute(name, callArgs)
                    } catch (e: Exception) {
                        "ERROR: tool $name failed: ${e.message ?: "unknown error"}"
                    }
                    val responseJson = JSONObject()
                        .put(
                            "toolResponse", JSONObject()
                                .put(
                                    "functionResponses", JSONArray().put(
                                        JSONObject()
                                            .put("id", id)
                                            .put("name", name)
                                            .put("response", JSONObject().put("result", result))
                                    )
                                )
                        )
                    webSocket?.send(responseJson.toString())
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Microphone capture
    // ------------------------------------------------------------------

    private fun startCapture() {
        if (captureStarted) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            listener.onState(STATE_ERROR)
            listener.onError("Microphone permission (RECORD_AUDIO) is not granted. Allow it for Darling to use Calling Mode.")
            return
        }
        val minBuffer = AudioRecord.getMinBufferSize(
            INPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuffer, CHUNK_BYTES * 2)
        val record = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                INPUT_SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (e: Exception) {
            listener.onState(STATE_ERROR)
            listener.onError("Microphone could not be opened: ${e.message ?: "error"}")
            return
        }
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            try { record.release() } catch (e: Exception) { /* ignore */ }
            listener.onState(STATE_ERROR)
            listener.onError("Microphone could not be initialised on this phone.")
            return
        }
        audioRecord = record
        captureStarted = true

        captureThread = Thread({
            val buffer = ByteArray(CHUNK_BYTES)
            var recording = false
            try {
                record.startRecording()
                recording = true
            } catch (e: Exception) {
                listener.onError("Microphone recording failed to start: ${e.message ?: "error"}")
            }
            while (recording && running && captureStarted) {
                val read = try {
                    record.read(buffer, 0, buffer.size)
                } catch (e: Exception) {
                    -1
                }
                if (read <= 0) continue

                val rms = computeRms(buffer, read)
                listener.onLevel(rms)
                handlePossibleBargeIn(rms)

                val chunk = if (read == buffer.size) buffer else buffer.copyOf(read)
                // Current Live protocol: realtimeInput.audio (mediaChunks is deprecated).
                val payload = JSONObject()
                    .put(
                        "realtimeInput", JSONObject()
                            .put(
                                "audio", JSONObject()
                                    .put("mimeType", "audio/pcm;rate=16000")
                                    .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
                            )
                    )
                webSocket?.send(payload.toString())
            }
        }, "darling-live-capture").apply { isDaemon = true; start() }
    }

    private fun stopCapture() {
        captureStarted = false
        try { audioRecord?.stop() } catch (e: Exception) { /* ignore */ }
        try { audioRecord?.release() } catch (e: Exception) { /* ignore */ }
        audioRecord = null
        captureThread = null
    }

    private fun computeRms(buffer: ByteArray, bytesRead: Int): Float {
        val samples = bytesRead / 2
        if (samples == 0) return 0f
        var sumSquares = 0.0
        var i = 0
        while (i + 1 < bytesRead) {
            val lo = buffer[i].toInt() and 0xFF
            val hi = buffer[i + 1].toInt()
            val sample = (hi shl 8) or lo
            val signed = if (sample >= 32768) sample - 65536 else sample
            val normalised = signed / 32768.0
            sumSquares += normalised * normalised
            i += 2
        }
        return sqrt(sumSquares / samples).toFloat().coerceIn(0f, 1f)
    }

    private fun handlePossibleBargeIn(rms: Float) {
        if (!modelSpeaking) {
            loudChunkCount = 0
            return
        }
        if (rms > BARGE_RMS_THRESHOLD) {
            loudChunkCount++
            if (loudChunkCount >= BARGE_CHUNKS_NEEDED) {
                loudChunkCount = 0
                flushPlayback()
                modelSpeaking = false
                suppressPlaybackUntilMs = System.currentTimeMillis() + 800
                listener.onState(STATE_LISTENING)
            }
        } else {
            loudChunkCount = 0
        }
    }

    // ------------------------------------------------------------------
    // Speaker playback
    // ------------------------------------------------------------------

    private fun initPlayback() {
        if (audioTrack != null) return
        val minBuffer = AudioTrack.getMinBufferSize(
            OUTPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUTPUT_SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuffer, OUTPUT_SAMPLE_RATE))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack = track
        try { track.play() } catch (e: Exception) { /* surfaced on first write */ }
    }

    private fun playAudioChunk(base64Data: String) {
        if (System.currentTimeMillis() < suppressPlaybackUntilMs) return
        val bytes = try {
            Base64.decode(base64Data, Base64.DEFAULT)
        } catch (e: Exception) {
            return
        }
        if (bytes.isEmpty()) return
        if (audioTrack == null) initPlayback()
        val track = audioTrack ?: return
        if (!modelSpeaking) {
            modelSpeaking = true
            listener.onState(STATE_SPEAKING)
        }
        try {
            if (track.playState != AudioTrack.PLAYSTATE_PLAYING) track.play()
            track.write(bytes, 0, bytes.size)
        } catch (e: Exception) {
            listener.onError("Audio playback failed: ${e.message ?: "error"}")
        }
    }

    private fun flushPlayback() {
        val track = audioTrack ?: return
        try {
            if (track.playState == AudioTrack.PLAYSTATE_PLAYING) track.pause()
            track.flush()
            track.play()
        } catch (e: Exception) { /* ignore */ }
    }

    private fun releasePlayback() {
        try { audioTrack?.pause() } catch (e: Exception) { /* ignore */ }
        try { audioTrack?.stop() } catch (e: Exception) { /* ignore */ }
        try { audioTrack?.release() } catch (e: Exception) { /* ignore */ }
        audioTrack = null
    }

    // ------------------------------------------------------------------
    // Misc
    // ------------------------------------------------------------------

    /** Removes the API key from any text before it reaches the UI/logs. */
    private fun sanitize(text: String): String {
        val key = settings.apiKey
        return if (key.isNotBlank()) text.replace(key, "***") else text
    }
}
