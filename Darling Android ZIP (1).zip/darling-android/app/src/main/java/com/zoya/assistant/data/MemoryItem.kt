package com.zoya.assistant.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * One long-term memory fact about the user, stored as a key/value pair
 * (e.g. key = "home_city", value = "Ballia"). The [key] is unique, so
 * remembering a new value for the same key replaces the old one.
 */
@Entity(
    tableName = "memory_items",
    indices = [Index(value = ["key"], unique = true)]
)
data class MemoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val key: String,
    val value: String,
    val updatedAt: Long
)

@Dao
interface MemoryDao {

    @Query("SELECT * FROM memory_items ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<MemoryItem>>

    @Query("SELECT * FROM memory_items WHERE `key` = :key LIMIT 1")
    suspend fun getByKey(key: String): MemoryItem?

    /** One-shot snapshot of all memories (used by tool calls). */
    @Query("SELECT * FROM memory_items ORDER BY updatedAt DESC")
    suspend fun allOnce(): List<MemoryItem>

    /** Insert or replace the value stored under [MemoryItem.key]. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: MemoryItem)

    @Delete
    suspend fun delete(item: MemoryItem)

    @Query("DELETE FROM memory_items WHERE `key` = :key")
    suspend fun deleteByKey(key: String)

    @Query("DELETE FROM memory_items")
    suspend fun clear()
}
