package com.zoya.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoya.assistant.ui.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    val apiTest by vm.apiTest.collectAsState()

    var apiKey by remember { mutableStateOf(s.apiKey) }
    var liveModel by remember { mutableStateOf(s.liveModel) }
    var chatModel by remember { mutableStateOf(s.chatModel) }
    var voiceName by remember { mutableStateOf(s.voiceName) }
    var personality by remember { mutableStateOf(s.personality) }
    var confirmSend by remember { mutableStateOf(s.confirmBeforeSend) }
    var rapidKey by remember { mutableStateOf(s.rapidApiKey) }
    var trainUrl by remember { mutableStateOf(s.trainApiUrlTemplate) }
    var picoKey by remember { mutableStateOf(s.picovoiceKey) }
    var emergencyContact by remember { mutableStateOf(s.emergencyContact) }
    var savedTick by remember { mutableStateOf("") }

    fun saveAll() {
        s.apiKey = apiKey.trim()
        s.liveModel = liveModel.trim().ifBlank { "gemini-3.8-live" }
        s.chatModel = chatModel.trim().ifBlank { "gemini-3.8-flash" }
        s.voiceName = voiceName.trim().ifBlank { "Kore" }
        s.personality = personality
        s.confirmBeforeSend = confirmSend
        s.rapidApiKey = rapidKey.trim()
        s.trainApiUrlTemplate = trainUrl.trim()
        s.picovoiceKey = picoKey.trim()
        s.emergencyContact = emergencyContact.trim()
        savedTick = "Save ho gaya ✓"
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)
    ) {
        Text("Settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))

        Text("Gemini API Key", color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            apiKey, { apiKey = it }, Modifier.fillMaxWidth(),
            label = { Text("Gemini API Key") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true
        )
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { saveAll(); vm.testApiKey() }) { Text("Save + Test karo") }
            if (savedTick.isNotBlank()) Text(savedTick, color = Color(0xFF34D399), modifier = Modifier.align(Alignment.CenterVertically))
        }
        if (apiTest.isNotBlank()) {
            Text(apiTest, color = Color(0xFFFBBF24))
        }
        Spacer(Modifier.height(16.dp))

        Text("Models (advanced)", color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
        OutlinedTextField(liveModel, { liveModel = it }, Modifier.fillMaxWidth(), label = { Text("Live voice model") }, singleLine = true)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(chatModel, { chatModel = it }, Modifier.fillMaxWidth(), label = { Text("Chat model") }, singleLine = true)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(voiceName, { voiceName = it }, Modifier.fillMaxWidth(), label = { Text("Voice name (Kore, Puck, Charon, Aoede...)") }, singleLine = true)
        Spacer(Modifier.height(12.dp))

        Text("Personality", color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Flirty", "Sweet", "Serious").forEach { mode ->
                if (personality == mode) {
                    Button(onClick = { personality = mode }) { Text(mode) }
                } else {
                    OutlinedButton(onClick = { personality = mode }) { Text(mode) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Message bhejne se pehle confirm", color = Color.White)
            }
            Switch(checked = confirmSend, onCheckedChange = { confirmSend = it })
        }
        Spacer(Modifier.height(16.dp))

        Text("Train API (optional)", color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
        Text("Khali = NTES website khulegi.", color = Color(0xFF94A3B8))
        OutlinedTextField(rapidKey, { rapidKey = it }, Modifier.fillMaxWidth(), label = { Text("RapidAPI Key (optional)") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(trainUrl, { trainUrl = it }, Modifier.fillMaxWidth(), label = { Text("Train API URL template — https://.../{train}") })
        Spacer(Modifier.height(12.dp))

        Text("Emergency contact (SOS)", color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
        Text("SOS par is number par SMS + call jayega, location ke saath.", color = Color(0xFF94A3B8))
        OutlinedTextField(emergencyContact, { emergencyContact = it }, Modifier.fillMaxWidth(), label = { Text("Emergency contact number") }, singleLine = true)
        Spacer(Modifier.height(12.dp))

        Text("Picovoice Key (optional)", color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
        OutlinedTextField(picoKey, { picoKey = it }, Modifier.fillMaxWidth(), label = { Text("Picovoice AccessKey") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Spacer(Modifier.height(16.dp))

        Button(onClick = { saveAll() }, Modifier.fillMaxWidth()) { Text("Sab Save karo") }
        if (savedTick.isNotBlank()) Text(savedTick, color = Color(0xFF34D399))
        Spacer(Modifier.height(24.dp))
    }
}
