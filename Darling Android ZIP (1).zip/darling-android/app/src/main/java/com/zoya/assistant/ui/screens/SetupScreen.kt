package com.zoya.assistant.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoya.assistant.service.WakeWordService
import com.zoya.assistant.ui.AppViewModel

@Composable
fun SetupScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val voiceStatus by vm.voiceStatus.collectAsState()
    val memories by vm.memories.collectAsState()

    var wakeOn by remember { mutableStateOf(vm.settings.wakeWordEnabled) }
    var ownerOnly by remember { mutableStateOf(vm.settings.ownerOnly) }
    var autoAnswer by remember { mutableStateOf(vm.settings.autoAnswer) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* results handled by system; user can re-check by using features */ }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)
    ) {
        Text("Setup", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220))) {
            Column(Modifier.padding(12.dp)) {
                Text("Permissions", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    permLauncher.launch(
                        arrayOf(
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.CALL_PHONE,
                            Manifest.permission.ANSWER_PHONE_CALLS,
                            Manifest.permission.READ_PHONE_STATE,
                            Manifest.permission.SEND_SMS,
                            Manifest.permission.READ_SMS,
                            Manifest.permission.READ_CONTACTS,
                            Manifest.permission.POST_NOTIFICATIONS,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }) { Text("Permissions do") }
            }
        }
        Spacer(Modifier.height(10.dp))

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220))) {
            Column(Modifier.padding(12.dp)) {
                Text("Accessibility", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Screen control + WhatsApp auto-send.", color = Color(0xFF94A3B8))
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Accessibility Settings kholo") }
            }
        }
        Spacer(Modifier.height(10.dp))

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220))) {
            Column(Modifier.padding(12.dp)) {
                Text("Notification access", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Aaye hue message padhne ke liye.", color = Color(0xFF94A3B8))
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Notification Access kholo") }
            }
        }
        Spacer(Modifier.height(10.dp))

        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220))) {
            Column(Modifier.padding(12.dp)) {
                Text("Battery", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Wake word background me chale, isliye.", color = Color(0xFF94A3B8))
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    val intent = Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + context.packageName)
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                }) { Text("Battery restriction hatao") }
            }
        }
        Spacer(Modifier.height(14.dp))

        Text("Controls", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Wake Word — \"Hey Darling\"", color = Color.White)
                Text("Background me sunegi.", color = Color(0xFF94A3B8))
            }
            Switch(checked = wakeOn, onCheckedChange = {
                wakeOn = it
                vm.settings.wakeWordEnabled = it
                if (it) WakeWordService.start(context) else WakeWordService.stop(context)
            })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sirf meri awaaz (Owner Only)", color = Color.White)
                Text("Voiceprint match par hi kaam.", color = Color(0xFF94A3B8))
            }
            Switch(checked = ownerOnly, onCheckedChange = {
                ownerOnly = it
                vm.settings.ownerOnly = it
            })
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Auto-answer call", color = Color.White)
                Text("Call ~2.5 sec me khud uthayegi.", color = Color(0xFF94A3B8))
            }
            Switch(checked = autoAnswer, onCheckedChange = {
                autoAnswer = it
                vm.settings.autoAnswer = it
            })
        }
        Spacer(Modifier.height(10.dp))
        Text(voiceStatus, color = Color(0xFF67E8F9))
        Spacer(Modifier.height(6.dp))
        Row {
            Button(onClick = { vm.enrollVoice() }) { Text("🎤 Awaaz enroll karo") }
            Spacer(Modifier.padding(6.dp))
            OutlinedButton(onClick = { vm.verifyVoice() }) { Text("Awaaz test karo") }
        }
        Spacer(Modifier.height(16.dp))

        Text("Memory (${memories.size})", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        memories.forEach { item ->
            Card(Modifier.fillMaxWidth().padding(bottom = 6.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1220))) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.key, color = Color(0xFF67E8F9))
                        Text(item.value, color = Color.White)
                    }
                    OutlinedButton(onClick = { vm.deleteMemory(item) }) { Text("Bhool jao") }
                }
            }
        }
        if (memories.isNotEmpty()) {
            OutlinedButton(onClick = { vm.clearMemories() }) { Text("Saari memory saaf karo") }
        }
        Spacer(Modifier.height(24.dp))
    }
}
