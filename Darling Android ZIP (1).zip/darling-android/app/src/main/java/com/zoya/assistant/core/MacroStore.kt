package com.zoya.assistant.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One step inside a saved macro. [verb] is one of the supported actions. */
data class MacroStep(
    val verb: String,
    val text: String = "",
    val seconds: Int = 0
)

/** A named, replayable routine: an ordered list of [MacroStep]s. */
data class Macro(
    val name: String,
    val steps: List<MacroStep>
)

/**
 * Persists Darling's macros (taught routines) in a small JSON file in the
 * app's private filesDir ("darling_macros.json").
 *
 * A macro is a simple ordered list of steps in the shape:
 *   [{"verb":"open_app","text":"YouTube"},
 *    {"verb":"wait","seconds":2},
 *    {"verb":"tap_text","text":"Search"},
 *    {"verb":"type_text","text":"lofi music"},
 *    {"verb":"go_back"}, {"verb":"go_home"}]
 *
 * Supported verbs: open_app, tap_text, type_text, go_back, go_home, wait.
 * Playback lives in ToolRegistry (it owns the accessibility bridge and
 * the app launcher); this class only stores/loads definitions.
 *
 * All functions are synchronous file IO on small data — call them from a
 * background thread/coroutine, never the main thread hot path. Every
 * function fails soft (empty result / false) instead of throwing.
 */
class MacroStore(context: Context) {

    private val file: File = File(context.applicationContext.filesDir, FILE_NAME)

    /** All saved macros, in the order they were first saved. */
    fun list(): List<Macro> {
        val root = readRoot() ?: return emptyList()
        val arr = root.optJSONArray(KEY_MACROS) ?: return emptyList()
        val out = ArrayList<Macro>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val name = obj.optString("name").trim()
            if (name.isEmpty()) continue
            out.add(Macro(name = name, steps = parseSteps(obj.optJSONArray("steps"))))
        }
        return out
    }

    /** One macro by name (case-insensitive), or null when not saved. */
    fun get(name: String): Macro? {
        val wanted = name.trim()
        if (wanted.isEmpty()) return null
        return list().firstOrNull { it.name.equals(wanted, ignoreCase = true) }
    }

    /**
     * Saves (or replaces, when the name already exists) a macro whose
     * steps arrive as a JSON array string in the documented shape.
     * Returns a human-readable error string, or null on success.
     */
    fun save(name: String, stepsJson: String): String? {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return "macro name is empty"
        val stepsArray = try {
            JSONArray(stepsJson)
        } catch (e: Exception) {
            return "steps_json is not a valid JSON array: ${e.message ?: "parse error"}"
        }
        val steps = parseSteps(stepsArray)
        if (steps.isEmpty()) return "macro has no valid steps"
        for (step in steps) {
            if (step.verb !in SUPPORTED_VERBS) {
                return "unsupported step verb '${step.verb}' " +
                    "(supported: ${SUPPORTED_VERBS.joinToString(", ")})"
            }
        }

        val macros = list().filterNot { it.name.equals(cleanName, ignoreCase = true) } +
            Macro(name = cleanName, steps = steps)
        return if (writeAll(macros)) null else "could not write the macro file"
    }

    /** Deletes a macro by name. Returns true when something was removed. */
    fun delete(name: String): Boolean {
        val wanted = name.trim()
        if (wanted.isEmpty()) return false
        val current = list()
        val kept = current.filterNot { it.name.equals(wanted, ignoreCase = true) }
        if (kept.size == current.size) return false
        return writeAll(kept)
    }

    // ------------------------------------------------------------------

    private fun parseSteps(arr: JSONArray?): List<MacroStep> {
        if (arr == null) return emptyList()
        val out = ArrayList<MacroStep>()
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val verb = obj.optString("verb").trim().lowercase()
            if (verb.isEmpty()) continue
            out.add(
                MacroStep(
                    verb = verb,
                    text = obj.optString("text"),
                    seconds = obj.optInt("seconds", 0).coerceIn(0, 120)
                )
            )
        }
        return out
    }

    private fun readRoot(): JSONObject? {
        return try {
            if (!file.exists()) null else JSONObject(file.readText())
        } catch (e: Exception) {
            null
        }
    }

    private fun writeAll(macros: List<Macro>): Boolean {
        return try {
            val arr = JSONArray()
            for (macro in macros) {
                val stepsArr = JSONArray()
                for (step in macro.steps) {
                    stepsArr.put(
                        JSONObject()
                            .put("verb", step.verb)
                            .put("text", step.text)
                            .put("seconds", step.seconds)
                    )
                }
                arr.put(
                    JSONObject()
                        .put("name", macro.name)
                        .put("steps", stepsArr)
                )
            }
            file.writeText(JSONObject().put(KEY_MACROS, arr).toString())
            true
        } catch (e: Exception) {
            false
        }
    }

    private companion object {
        const val FILE_NAME = "darling_macros.json"
        const val KEY_MACROS = "macros"
        val SUPPORTED_VERBS = listOf("open_app", "tap_text", "type_text", "go_back", "go_home", "wait")
    }
}
