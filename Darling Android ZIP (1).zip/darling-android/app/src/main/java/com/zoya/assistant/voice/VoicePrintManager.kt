package com.zoya.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Very small on-device "owner voice" check.
 *
 * Enrollment records ~2.5 s of the owner speaking and reduces it to a
 * compact feature vector: overall level statistics (mean / std of frame
 * RMS), voicing statistics (mean zero-crossing rate) and a coarse spectral
 * shape (12 log band energies, computed with the Goertzel algorithm —
 * i.e. single-bin DFT magnitudes — averaged over all frames). The vector
 * is L2-normalised and persisted in SharedPreferences.
 *
 * Verification records the same way and compares by cosine similarity
 * against a [THRESHOLD]. This is a convenience gate, not biometric-grade
 * security: a good recording of the owner can fool it, which is why
 * sensitive actions in the app still ask for confirmation.
 */
class VoicePrintManager(private val context: Context) {

    private val appContext: Context = context.applicationContext

    private val prefs =
        appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isEnrolled(): Boolean = loadVector() != null

    /**
     * Records the owner and saves the resulting feature vector.
     * @throws SecurityException when RECORD_AUDIO is not granted.
     */
    suspend fun enroll(): FloatArray {
        val samples = recordSamples()
        val vector = computeFeatures(samples)
        prefs.edit()
            .putString(KEY_VECTOR, vector.joinToString(",") { it.toString() })
            .apply()
        return vector
    }

    /**
     * Records a fresh sample and compares it with the enrolled vector.
     * @return (matches, cosine similarity); similarity is 0f when not enrolled.
     * @throws SecurityException when RECORD_AUDIO is not granted.
     */
    suspend fun verify(): Pair<Boolean, Float> {
        val enrolled = loadVector() ?: return Pair(false, 0f)
        val samples = recordSamples()
        val current = computeFeatures(samples)
        val similarity = cosineSimilarity(current, enrolled)
        return Pair(similarity >= THRESHOLD, similarity)
    }

    // ------------------------------------------------------------------
    // Persistence
    // ------------------------------------------------------------------

    private fun loadVector(): FloatArray? {
        val raw = prefs.getString(KEY_VECTOR, null)?.takeIf { it.isNotBlank() }
            ?: return null
        return try {
            val values = raw.split(",").map { it.trim().toFloat() }
            if (values.size == FEATURE_COUNT) values.toFloatArray() else null
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------
    // Recording
    // ------------------------------------------------------------------

    private suspend fun recordSamples(): ShortArray =
        withContext(Dispatchers.IO) {
            if (ContextCompat.checkSelfPermission(
                    appContext,
                    Manifest.permission.RECORD_AUDIO
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                throw SecurityException("RECORD_AUDIO permission not granted")
            }

            val totalSamples = SAMPLE_RATE * RECORD_MILLIS / 1000
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBuffer, FRAME_SAMPLES * 2)

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            try {
                if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("AudioRecord failed to initialise")
                }
                val samples = ShortArray(totalSamples)
                recorder.startRecording()
                var offset = 0
                while (offset < totalSamples) {
                    val read = recorder.read(
                        samples,
                        offset,
                        totalSamples - offset
                    )
                    if (read <= 0) break
                    offset += read
                }
                if (offset == 0) {
                    throw IllegalStateException("No audio was recorded")
                }
                if (offset == totalSamples) samples else samples.copyOf(offset)
            } finally {
                try {
                    if (recorder.recordingState ==
                        AudioRecord.RECORDSTATE_RECORDING
                    ) {
                        recorder.stop()
                    }
                } catch (e: Exception) {
                    // Ignore; release below is what matters.
                }
                try {
                    recorder.release()
                } catch (e: Exception) {
                    // Ignore.
                }
            }
        }

    // ------------------------------------------------------------------
    // Feature extraction
    // ------------------------------------------------------------------

    private fun computeFeatures(samples: ShortArray): FloatArray {
        val frameCount = samples.size / FRAME_SAMPLES
        require(frameCount > 0) { "Recording too short" }

        var rmsSum = 0.0
        var rmsSqSum = 0.0
        var zcrSum = 0.0
        val bandLogEnergies = DoubleArray(BAND_COUNT)

        val frame = DoubleArray(FRAME_SAMPLES)

        for (f in 0 until frameCount) {
            val start = f * FRAME_SAMPLES
            var sqSum = 0.0
            var crossings = 0
            var prevSign = 0
            for (i in 0 until FRAME_SAMPLES) {
                val v = samples[start + i].toDouble() / Short.MAX_VALUE
                frame[i] = v
                sqSum += v * v
                val sign = when {
                    v > 0 -> 1
                    v < 0 -> -1
                    else -> 0
                }
                if (prevSign != 0 && sign != 0 && sign != prevSign) {
                    crossings++
                }
                if (sign != 0) prevSign = sign
            }
            val rms = sqrt(sqSum / FRAME_SAMPLES)
            rmsSum += rms
            rmsSqSum += rms * rms
            zcrSum += crossings.toDouble() / FRAME_SAMPLES

            for (b in 0 until BAND_COUNT) {
                val power = goertzelPower(frame, bandCenterHz(b))
                bandLogEnergies[b] += ln(power + 1.0)
            }
        }

        val meanRms = rmsSum / frameCount
        val variance = (rmsSqSum / frameCount) - meanRms * meanRms
        val stdRms = sqrt(if (variance > 0) variance else 0.0)
        val meanZcr = zcrSum / frameCount

        val features = FloatArray(FEATURE_COUNT)
        features[0] = meanRms.toFloat()
        features[1] = stdRms.toFloat()
        features[2] = meanZcr.toFloat()
        for (b in 0 until BAND_COUNT) {
            // Average log band energy, scaled down so its magnitude is
            // comparable with the level statistics above.
            features[3 + b] = (bandLogEnergies[b] / frameCount / 10.0).toFloat()
        }

        // L2-normalise to unit length so cosine similarity is a plain dot.
        var norm = 0.0
        for (v in features) norm += v.toDouble() * v
        norm = sqrt(norm)
        if (norm > 0) {
            for (i in features.indices) {
                features[i] = (features[i] / norm).toFloat()
            }
        }
        return features
    }

    /** Log-spaced band centres from 100 Hz up to 8 kHz. */
    private fun bandCenterHz(index: Int): Double {
        val low = 100.0
        val high = 8000.0
        return low * Math.pow(high / low, index.toDouble() / (BAND_COUNT - 1))
    }

    /**
     * Power of a single DFT bin at [freqHz] over [frame], computed with
     * the Goertzel recurrence (equivalent to a 1-bin DFT without a full
     * FFT).
     */
    private fun goertzelPower(frame: DoubleArray, freqHz: Double): Double {
        val omega = 2.0 * PI * freqHz / SAMPLE_RATE
        val coeff = 2.0 * cos(omega)
        var sPrev = 0.0
        var sPrev2 = 0.0
        for (sample in frame) {
            val s = sample + coeff * sPrev - sPrev2
            sPrev2 = sPrev
            sPrev = s
        }
        return sPrev * sPrev + sPrev2 * sPrev2 - coeff * sPrev * sPrev2
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        val size = minOf(a.size, b.size)
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in 0 until size) {
            dot += a[i].toDouble() * b[i]
            normA += a[i].toDouble() * a[i]
            normB += b[i].toDouble() * b[i]
        }
        val denom = sqrt(normA) * sqrt(normB)
        if (denom == 0.0) return 0f
        return (dot / denom).toFloat().coerceIn(-1f, 1f)
    }

    companion object {
        private const val PREFS_NAME = "darling_voiceprint"
        private const val KEY_VECTOR = "vector"

        private const val SAMPLE_RATE = 16000
        private const val RECORD_MILLIS = 2500

        /** 25 ms frames at 16 kHz. */
        private const val FRAME_SAMPLES = 400

        private const val BAND_COUNT = 12

        /** mean RMS, std RMS, mean ZCR + band energies. */
        private const val FEATURE_COUNT = 3 + BAND_COUNT

        private const val THRESHOLD = 0.80f
    }
}
