package com.zoya.assistant.service

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/** One captured incoming notification (WhatsApp, SMS, etc.). */
data class IncomingMsg(
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val time: Long
)

/**
 * In-memory store for recent incoming messages captured by
 * [DarlingNotificationService], together with the notification reply actions
 * (PendingIntent + RemoteInput) that let Darling reply inline where the
 * source app supports it (e.g. WhatsApp / Messages quick reply).
 */
object NotificationStore {

    private const val MAX_ITEMS = 50

    private val items = CopyOnWriteArrayList<IncomingMsg>()

    /** Reply actions keyed by StatusBarNotification.key. */
    private val replyActions =
        ConcurrentHashMap<String, Pair<PendingIntent, RemoteInput>>()

    /** Maps a stored message to the notification key that produced it. */
    private val keyByMsg = ConcurrentHashMap<IncomingMsg, String>()

    fun add(
        msg: IncomingMsg,
        sbnKey: String,
        replyPair: Pair<PendingIntent, RemoteInput>? = null
    ) {
        items.add(msg)
        keyByMsg[msg] = sbnKey
        if (replyPair != null) {
            replyActions[sbnKey] = replyPair
        }
        // Cap the list, dropping the oldest entries (and their reply data
        // when no remaining message still references the same key).
        while (items.size > MAX_ITEMS) {
            val removed = items.removeAt(0) ?: break
            val removedKey = keyByMsg.remove(removed)
            if (removedKey != null && keyByMsg.values.none { it == removedKey }) {
                replyActions.remove(removedKey)
            }
        }
    }

    /** Most recent messages first. */
    fun latest(limit: Int): List<IncomingMsg> {
        if (limit <= 0) return emptyList()
        return items.takeLast(limit).reversed()
    }

    /** Human/LLM readable lines: "App: title — text", most recent first. */
    fun latestText(limit: Int): String =
        latest(limit).joinToString("\n") { "${it.appLabel}: ${it.title} — ${it.text}" }

    /**
     * Replies to the most recent message from [packageName] using the reply
     * action stored with its notification. Returns false when that app has
     * no stored reply action (e.g. it does not support inline reply).
     */
    fun replyToLatestFrom(packageName: String, message: String): Boolean {
        val msg = items.lastOrNull { it.packageName == packageName } ?: return false
        val key = keyByMsg[msg] ?: return false
        val (pendingIntent, remoteInput) = replyActions[key] ?: return false
        return try {
            val intent = Intent()
            val results = Bundle().apply {
                putCharSequence(remoteInput.resultKey, message)
            }
            RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, results)
            pendingIntent.send()
            true
        } catch (e: Exception) {
            false
        }
    }
}
