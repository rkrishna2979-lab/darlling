package com.zoya.assistant.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zoya.assistant.R
import com.zoya.assistant.core.SettingsStore

/**
 * Watches phone state for incoming calls.
 *
 * On RINGING it posts a "darling_calls" notification announcing the caller
 * (contact name when it can be looked up, otherwise the number) and, when
 * the user has enabled auto-answer in settings and granted the
 * ANSWER_PHONE_CALLS permission, answers the call after ~2.5 seconds via
 * [TelecomManager.acceptRingingCall].
 */
class CallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val contactName = if (!number.isNullOrBlank()) {
            lookupContactName(context, number)
        } else {
            null
        }
        val displayName = contactName ?: number?.takeIf { it.isNotBlank() } ?: "Unknown"

        postCallNotification(context, displayName)

        maybeAutoAnswer(context)
    }

    private fun lookupContactName(context: Context, number: String): String? {
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx =
                        cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun postCallNotification(context: Context, displayName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        try {
            val manager =
                context.getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                manager.getNotificationChannel(CHANNEL_ID) == null
            ) {
                manager.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Darling Calls",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                )
            }
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_darling)
                .setContentTitle("Call aa raha hai: $displayName")
                .setContentText("Darling ko bolo: call uthao")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            manager.notify(
                (System.currentTimeMillis() % 100000).toInt(),
                notification
            )
        } catch (e: Exception) {
            // Notification is best-effort; never crash on a phone-state event.
        }
    }

    private fun maybeAutoAnswer(context: Context) {
        val autoAnswer = try {
            SettingsStore(context).autoAnswer
        } catch (e: Exception) {
            false
        }
        if (!autoAnswer) return

        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ANSWER_PHONE_CALLS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val appContext = context.applicationContext
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val telecom = appContext.getSystemService(
                    Context.TELECOM_SERVICE
                ) as? TelecomManager
                @Suppress("DEPRECATION")
                telecom?.acceptRingingCall()
            } catch (e: Exception) {
                // Call may already have ended or been answered manually.
            }
        }, AUTO_ANSWER_DELAY_MS)
    }

    companion object {
        private const val CHANNEL_ID = "darling_calls"
        private const val AUTO_ANSWER_DELAY_MS = 2500L
    }
}
