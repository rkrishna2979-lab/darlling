package com.zoya.assistant.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zoya.assistant.R

/**
 * Fires a high-priority notification for a scheduled reminder.
 *
 * The reminder text arrives in the "title" intent extra (scheduled with
 * AlarmManager by the reminders tool). Creates the "darling_reminders"
 * channel (IMPORTANCE_HIGH) on first use and vibrates with the
 * notification.
 */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val title = intent?.getStringExtra("title") ?: "Reminder"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        try {
            val manager =
                context.getSystemService(NotificationManager::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                manager.getNotificationChannel(CHANNEL_ID) == null
            ) {
                manager.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Darling Reminders",
                        NotificationManager.IMPORTANCE_HIGH
                    )
                )
            }
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_darling)
                .setContentTitle("Darling Reminder")
                .setContentText(title)
                .setStyle(NotificationCompat.BigTextStyle().bigText(title))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setVibrate(longArrayOf(0, 250, 150, 250))
                .setAutoCancel(true)
                .build()
            manager.notify(
                (System.currentTimeMillis() % 100000).toInt(),
                notification
            )
        } catch (e: Exception) {
            // Best-effort only; a missed post must not crash the receiver.
        }
    }

    companion object {
        private const val CHANNEL_ID = "darling_reminders"
    }
}
