package com.zoya.assistant.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zoya.assistant.ui.AppViewModel

private fun stateColor(state: String): Color = when (state) {
    "LISTENING" -> Color(0xFF22D3EE)
    "SPEAKING" -> Color(0xFF34D399)
    "THINKING", "CONNECTING" -> Color(0xFFFBBF24)
    "ERROR" -> Color(0xFFF87171)
    else -> Color(0xFF64748B)
}

private fun stateLabel(state: String): String = when (state) {
    "LISTENING" -> "Sun rahi hu…"
    "SPEAKING" -> "Bol rahi hu…"
    "THINKING" -> "Soch rahi hu…"
    "CONNECTING" -> "Connect ho raha hai…"
    "ERROR" -> "Kuch atka hai"
    else -> "Tap karo — baat shuru karte hain"
}

/**
 * Darling's home: a single full-screen voice experience.
 * One glowing mic orb in the centre (tap = start/stop), one status line,
 * one line of live text. Nothing else — no chips, no tips, no clutter.
 */
@Composable
fun VoiceScreen(vm: AppViewModel) {
    val state by vm.liveState.collectAsState()
    val level by vm.liveLevel.collectAsState()
    val userText by vm.liveUserText.collectAsState()
    val modelText by vm.liveModelText.collectAsState()
    val error by vm.liveError.collectAsState()
    val color = stateColor(state)
    val running = state == "CONNECTING" || state == "LISTENING" ||
        state == "THINKING" || state == "SPEAKING"

    val pulse = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulseScale"
    )
    val animatedLevel by animateFloatAsState(level.coerceIn(0f, 1f), label = "lvl")

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF0B1E33), Color(0xFF050914))))
    ) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(26.dp))
            Text("D A R L I N G", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE2E8F0))
            Spacer(Modifier.weight(1f))

            Box(
                Modifier
                    .size(250.dp)
                    .clickable { if (running) vm.stopLive() else vm.startLive() },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val base = size.minDimension / 2f
                    val breathe = if (state == "LISTENING" || state == "CONNECTING") pulseScale else 1f
                    drawCircle(color = color.copy(alpha = 0.10f), radius = base * breathe)
                    drawCircle(color = color.copy(alpha = 0.20f), radius = base * 0.78f * (1f + animatedLevel * 0.25f))
                    drawCircle(color = color.copy(alpha = 0.9f), radius = base * 0.52f * (1f + animatedLevel * 0.20f))
                }
                Text(if (running) "⏸" else "🎙", fontSize = 54.sp)
            }
            Spacer(Modifier.height(22.dp))
            Text(stateLabel(state), color = color, fontSize = 18.sp, fontWeight = FontWeight.Medium)

            Box(
                Modifier.fillMaxWidth().height(80.dp).padding(top = 14.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                when {
                    error.isNotBlank() ->
                        Text(error, color = Color(0xFFF87171), fontSize = 13.sp, textAlign = TextAlign.Center)
                    modelText.isNotBlank() ->
                        Text(
                            modelText, color = Color.White, fontSize = 15.sp,
                            textAlign = TextAlign.Center, maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    userText.isNotBlank() ->
                        Text(
                            "“$userText”", color = Color(0xFF94A3B8), fontSize = 14.sp,
                            textAlign = TextAlign.Center, maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                }
            }
            Spacer(Modifier.weight(1f))

            when {
                state == "SPEAKING" ->
                    TextButton(onClick = { vm.interruptLive() }) { Text("✋ Roko", color = Color(0xFF67E8F9), fontSize = 15.sp) }
                running ->
                    TextButton(onClick = { vm.stopLive() }) { Text("Band karo", color = Color(0xFF94A3B8), fontSize = 15.sp) }
                else -> Spacer(Modifier.height(48.dp))
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
