package com.zoya.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.zoya.assistant.MainActivity
import com.zoya.assistant.R

/**
 * Foreground service that keeps listening for the wake word "Darling" using
 * the system [SpeechRecognizer] in a restart loop.
 *
 * On detection it vibrates briefly and opens [MainActivity] in calling
 * mode (extra "darling_action" = "OPEN_CALLING"). A partial wake lock is held
 * while the service runs so listening survives the screen going off; the
 * permanent low-priority notification is the Android-mandated cost.
 */
class WakeWordService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile
    private var running = false

    private var restartScheduled = false

    private val restartRunnable = Runnable {
        restartScheduled = false
        if (running) startListening()
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            scheduleRestart()
        }

        override fun onError(error: Int) {
            scheduleRestart()
        }

        override fun onResults(results: Bundle?) {
            handleResults(results)
            scheduleRestart()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            handleResults(partialResults)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        val notification = buildNotification()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                try {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    )
                } catch (e: Exception) {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // If foreground start is refused, still try to listen; the
            // system will kill us eventually, START_STICKY asks for a retry.
        }

        acquireWakeLock()

        if (!running) {
            running = true
            startListening()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        releaseWakeLock()
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Listening loop
    // ------------------------------------------------------------------

    private fun startListening() {
        if (!running) return
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return
            destroyRecognizer()
            val rec = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = rec
            rec.setRecognitionListener(recognitionListener)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            rec.startListening(intent)
        } catch (e: Exception) {
            scheduleRestart()
        }
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.destroy()
        } catch (e: Exception) {
            // Ignore.
        }
        recognizer = null
    }

    private fun scheduleRestart() {
        if (!running || restartScheduled) return
        restartScheduled = true
        handler.postDelayed(restartRunnable, RESTART_DELAY_MS)
    }

    private fun handleResults(results: Bundle?) {
        val texts = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?: return
        val joined = texts.joinToString(" ").lowercase()
        if (joined.contains(WAKE_WORD)) {
            onWakeWordDetected()
        }
    }

    private fun onWakeWordDetected() {
        vibrate()
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("darling_action", "OPEN_CALLING")
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Activity could not be launched (background restrictions);
            // the user can still open Darling manually.
        }
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager =
                    getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            }
        } catch (e: Exception) {
            // Vibration is a nicety only.
        }
    }

    // ------------------------------------------------------------------
    // Foreground notification / wake lock
    // ------------------------------------------------------------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Darling Wake Word",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_darling)
            .setContentTitle("Darling sun rahi hai")
            .setContentText("Wake word: Hey Darling")
            .setContentIntent(openIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val powerManager =
                getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "darling:wake"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            // Without a wake lock, listening just stops when the CPU sleeps.
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) {
            // Ignore.
        }
        wakeLock = null
    }

    companion object {
        private const val CHANNEL_ID = "darling_wake"
        private const val NOTIFICATION_ID = 42
        private const val RESTART_DELAY_MS = 400L
        private const val WAKE_WORD = "darling"

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, WakeWordService::class.java)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }
}
