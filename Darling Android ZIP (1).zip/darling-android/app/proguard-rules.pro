# Darling — default ProGuard/R8 rules (release minification is currently off).
# Add project-specific keep rules here.
